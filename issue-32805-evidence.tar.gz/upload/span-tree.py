#!/usr/bin/env python3
"""Print the span tree of the last N getArchivedShellSnapshot calls from server.trace.ndjson."""
import json
import sys
from collections import defaultdict

path, count = sys.argv[1], int(sys.argv[2]) if len(sys.argv) > 2 else 1
spans = []
for line in open(path):
    try:
        spans.append(json.loads(line))
    except ValueError:
        pass
children = defaultdict(list)
for s in spans:
    children[(s["traceId"], s.get("parentSpanId"))].append(s)
roots = [s for s in spans if s["name"] == "ws.rpc.orchestration.getArchivedShellSnapshot"][-count:]


def show(span, depth):
    attrs = span.get("attributes") or {}
    extra = " ".join(
        f"{k}={v}" for k, v in attrs.items() if "wait" in k or k in ("db.query.summary",)
    )
    print(f"{'  ' * depth}{span['name']:<{60 - 2 * depth}} {span['durationMs']:>9.1f}ms {extra}")
    for child in sorted(
        children[(span["traceId"], span["spanId"])], key=lambda c: int(c["startTimeUnixNano"])
    ):
        show(child, depth + 1)


for root in roots:
    show(root, 0)
    print()
