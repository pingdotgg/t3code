// Issue 32805 driver: times orchestration.getArchivedShellSnapshot over the real WS RPC,
// alone and while an API client bursts GET /api/orchestration/threads/:id.
// usage: T3_TOKEN=<bearer> node archive-timing.ts <origin> <burst-thread-id> [burst=20] [runs=3]
import * as NodeUtil from "node:util";
import * as Effect from "effect/Effect";
import * as Layer from "effect/Layer";
import * as Schema from "effect/Schema";
import { Socket } from "effect/socket";
import { RpcClient, RpcSerialization } from "effect/rpc";
import {
  ORCHESTRATION_PROTOCOL_HEADER,
  ORCHESTRATION_PROTOCOL_VERSION,
  WsRpcGroup,
} from "@t3tools/contracts";

const [origin, burstThreadId, burstArg = "20", runsArg = "3"] = process.argv.slice(2);
const token = process.env.T3_TOKEN;
if (!origin || !burstThreadId || !token) throw new Error("usage: see header");
const headers = {
  Authorization: `Bearer ${token}`,
  [ORCHESTRATION_PROTOCOL_HEADER]: String(ORCHESTRATION_PROTOCOL_VERSION),
};

const ticketResponse = await fetch(`${origin}/api/auth/websocket-ticket`, { method: "POST", headers });
if (!ticketResponse.ok) throw new Error(`ticket ${ticketResponse.status}`);
const { ticket } = Schema.decodeUnknownSync(Schema.Struct({ ticket: Schema.String }))(
  await ticketResponse.json(),
);
const layerProtocol = RpcClient.layerProtocolSocket().pipe(
  Layer.provide(
    Socket.layerWebSocket(
      `${origin.replace("http:", "ws:")}/ws?orchestrationProtocol=${ORCHESTRATION_PROTOCOL_VERSION}&wsTicket=${encodeURIComponent(ticket)}`,
    ).pipe(Layer.provide(Socket.layerWebSocketConstructorGlobal)),
  ),
  Layer.provide(RpcSerialization.layerJson),
);

const burst = (n: number) =>
  Array.from({ length: n }, async () => {
    const started = performance.now();
    const response = await fetch(
      `${origin}/api/orchestration/threads/${encodeURIComponent(burstThreadId)}`,
      { headers },
    );
    const body = await response.arrayBuffer();
    return { status: response.status, bytes: body.byteLength, ms: performance.now() - started };
  });

const program = Effect.gen(function* () {
  const client = yield* RpcClient.make(WsRpcGroup);
  const timeArchive = (label: string) =>
    Effect.gen(function* () {
      const started = performance.now();
      const snapshot = yield* client["orchestration.getArchivedShellSnapshot"]({});
      const ms = performance.now() - started;
      const bytes = JSON.stringify(snapshot).length;
      console.log(
        `${label}: getArchivedShellSnapshot ${ms.toFixed(0)} ms, ${snapshot.threads.length} threads, ${bytes} bytes`,
      );
    });
  for (let run = 1; run <= Number(runsArg); run++) yield* timeArchive(`quiet run ${run}`);
  for (let run = 1; run <= Number(runsArg); run++) {
    const requests = burst(Number(burstArg));
    yield* timeArchive(`with ${burstArg} concurrent thread GETs, run ${run}`);
    const results = yield* Effect.promise(() => Promise.all(requests));
    const times = results.map((r) => r.ms).sort((a, b) => a - b);
    console.log(
      `  burst: statuses ${[...new Set(results.map((r) => r.status))].join(",")}, ` +
        `p50 ${times[times.length >> 1]?.toFixed(0)} ms, max ${times.at(-1)?.toFixed(0)} ms, ` +
        `${results[0]?.bytes} bytes each`,
    );
  }
}).pipe(Effect.scoped, Effect.provide(layerProtocol));

await Effect.runPromise(program);
console.log(NodeUtil.format("done %s", new Date().toISOString()));
process.exit(0);
