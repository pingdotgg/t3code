#!/usr/bin/env python3
"""Scale a dev database for issue 32805.

Clones one template thread (created through the app by a Replay turn) into N archived
threads, each with about `items_per_thread` turn items. Synthetic data only; run it with
the dev server stopped, against the worktree's own fresh statev2.sqlite.

usage: scale_archive.py <statev2.sqlite> <template-thread-id> <count> [items_per_thread]
"""
import re
import sqlite3
import sys

db_path, template_id, count = sys.argv[1], sys.argv[2], int(sys.argv[3])
items_per_thread = int(sys.argv[4]) if len(sys.argv) > 4 else 50

db = sqlite3.connect(db_path)
db.row_factory = sqlite3.Row
uuid_re = re.compile(r"[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}")

tables = [
    r[0]
    for r in db.execute("select name from sqlite_master where type='table'")
    if any(c[1] == "thread_id" for c in db.execute(f"pragma table_info('{r[0]}')"))
]
template_rows = {
    t: [dict(r) for r in db.execute(f"select * from {t} where thread_id = ?", (template_id,))]
    for t in tables
}
template_rows = {t: rows for t, rows in template_rows.items() if rows}
# Every uuid inside the template's rows, except the project's, is rewritten per clone.
project_id = template_rows["orchestration_v2_projection_threads"][0]["project_id"]
uuids = set()
for rows in template_rows.values():
    for row in rows:
        for v in row.values():
            if isinstance(v, str):
                uuids.update(uuid_re.findall(v))
uuids.discard(project_id)
uuids = sorted(uuids)
print("tables", {t: len(r) for t, r in template_rows.items()}, "uuids", len(uuids))

items = template_rows.get("orchestration_v2_projection_turn_items", [])
copies = max(1, items_per_thread // max(1, len(items)))


def rewrite(value, i):
    if not isinstance(value, str):
        return value
    for k, u in enumerate(uuids):
        value = value.replace(u, f"{i:08x}-{k:04x}-4000-8000-{i:012x}")
    return value


db.execute("begin")
for i in range(1, count + 1):
    day = f"2026-{1 + (i % 10):02d}-{1 + (i % 27):02d}T{(i % 24):02d}:00:00.000Z"
    for table, rows in template_rows.items():
        for c in range(copies if table == "orchestration_v2_projection_turn_items" else 1):
            for row in rows:
                new = {k: rewrite(v, i) for k, v in row.items()}
                if c > 0:
                    new["turn_item_id"] = f"{new['turn_item_id']}:copy{c}"
                    new["ordinal"] = new["ordinal"] + c * 1000
                if table == "orchestration_v2_projection_threads":
                    new["archived_at"] = day
                    new["updated_at"] = day
                    new["title"] = f"Archived synthetic thread {i}"
                    new["payload_json"] = db.execute(
                        "select json_set(?, '$.archivedAt', ?, '$.updatedAt', ?, '$.title', ?)",
                        (new["payload_json"], day, day, new["title"]),
                    ).fetchone()[0]
                cols = ",".join(new)
                db.execute(
                    f"insert or ignore into {table} ({cols}) values ({','.join('?' * len(new))})",
                    list(new.values()),
                )
db.execute("commit")
for t in ("orchestration_v2_projection_threads", "orchestration_v2_projection_turn_items"):
    print(t, db.execute(f"select count(*) from {t}").fetchone()[0])
print(
    "archived",
    db.execute(
        "select count(*) from orchestration_v2_projection_threads where json_extract(payload_json,'$.archivedAt') is not null"
    ).fetchone()[0],
)
