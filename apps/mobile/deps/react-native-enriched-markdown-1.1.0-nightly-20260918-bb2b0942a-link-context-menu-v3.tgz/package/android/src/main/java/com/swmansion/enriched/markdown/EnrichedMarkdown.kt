package com.swmansion.enriched.markdown

import android.content.Context
import android.content.res.Configuration
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.View
import com.facebook.react.bridge.Arguments
import com.facebook.react.bridge.ReadableMap
import com.facebook.react.uimanager.PixelUtil
import com.facebook.react.uimanager.StateWrapper
import com.swmansion.enriched.markdown.accessibility.AccessibilityLabels
import com.swmansion.enriched.markdown.input.autolink.LinkRegexConfig
import com.swmansion.enriched.markdown.math.LatexErrorReporter
import com.swmansion.enriched.markdown.media.DocumentAsset
import com.swmansion.enriched.markdown.media.DocumentAssets
import com.swmansion.enriched.markdown.media.ImageSourceDecision
import com.swmansion.enriched.markdown.media.MediaOverride
import com.swmansion.enriched.markdown.media.MediaSlotView
import com.swmansion.enriched.markdown.media.documentAssetsEventData
import com.swmansion.enriched.markdown.media.emitMediaEvent
import com.swmansion.enriched.markdown.media.mediaSlotsForDocument
import com.swmansion.enriched.markdown.media.withImageSources
import com.swmansion.enriched.markdown.parser.Md4cFlags
import com.swmansion.enriched.markdown.parser.Parser
import com.swmansion.enriched.markdown.segments.BlockquoteContainerView
import com.swmansion.enriched.markdown.segments.CodeBlockContainerView
import com.swmansion.enriched.markdown.segments.ContainerNodeView
import com.swmansion.enriched.markdown.segments.DynamicBlockProps
import com.swmansion.enriched.markdown.segments.MarkdownSegmentRenderer
import com.swmansion.enriched.markdown.segments.RenderedSegment
import com.swmansion.enriched.markdown.segments.SegmentViewConfig
import com.swmansion.enriched.markdown.segments.SegmentViewCreators
import com.swmansion.enriched.markdown.segments.SegmentViewFactory
import com.swmansion.enriched.markdown.segments.TableContainerView
import com.swmansion.enriched.markdown.segments.splitASTIntoSegments
import com.swmansion.enriched.markdown.spoiler.SpoilerOverlay
import com.swmansion.enriched.markdown.styles.StyleConfig
import com.swmansion.enriched.markdown.utils.common.BreakStrategyUtils
import com.swmansion.enriched.markdown.utils.common.CodeBlockStreamingMode
import com.swmansion.enriched.markdown.utils.common.StreamingMarkdownFilter
import com.swmansion.enriched.markdown.utils.common.TableStreamingMode
import com.swmansion.enriched.markdown.utils.common.isReducedMotionEnabled
import com.swmansion.enriched.markdown.utils.text.TailFadeInAnimator
import com.swmansion.enriched.markdown.utils.text.view.ImagePressHost
import com.swmansion.enriched.markdown.utils.text.view.SelectionMenuConfig
import com.swmansion.enriched.markdown.utils.text.view.applySelectionColors
import com.swmansion.enriched.markdown.utils.text.view.emitImagePressEvent
import java.util.EnumSet
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

class EnrichedMarkdown(
  context: Context,
) : ContainerNodeView(context),
  ImagePressHost {
  private enum class DirtyFlag {
    RECREATE_SEGMENTS,
    FORCE_HEIGHT,
  }

  private val parser = Parser.shared
  private val mainHandler = Handler(Looper.getMainLooper())
  private val executor: ExecutorService = Executors.newSingleThreadExecutor()
  private val mathContainerClass: Class<*>? by lazy { SegmentViewCreators.mathContainerClass() }
  private val videoContainerClass: Class<*>? by lazy { SegmentViewCreators.videoContainerClass() }

  private var currentRenderId = 0L
  private var enableImageSourceResolution = false
  private var imageSourcesRevision = -1
  private var imageSourcesContinuityStart = 1
  private var imageSources = emptyList<ImageSourceDecision>()
  private var documentRevision = 0
  private var mediaOverridesRevision = -1
  private var enableDocumentAssets = false
  private var enableMediaSlots = false
  private var mediaOverrides = emptyList<MediaOverride>()
  private var acceptedRevision = -1
  private var acceptedAssets = emptyList<DocumentAsset>()
  private var lastAssetManifest: Pair<Int, List<DocumentAsset>>? = null
  private var lastMediaFrames: String? = null

  fun setEnableImageSourceResolution(value: Boolean) {
    if (enableImageSourceResolution == value) return
    enableImageSourceResolution = value
    dirtyFlags += DirtyFlag.RECREATE_SEGMENTS
    dirtyFlags += DirtyFlag.FORCE_HEIGHT
    renderPending = true
  }

  fun setImageSourcesRevision(value: Int) {
    if (imageSourcesRevision == value) return
    imageSourcesRevision = value
    dirtyFlags += DirtyFlag.RECREATE_SEGMENTS
    dirtyFlags += DirtyFlag.FORCE_HEIGHT
    renderPending = true
  }

  fun setImageSourcesContinuityStart(value: Int) {
    if (imageSourcesContinuityStart == value) return
    imageSourcesContinuityStart = value
    dirtyFlags += DirtyFlag.RECREATE_SEGMENTS
    dirtyFlags += DirtyFlag.FORCE_HEIGHT
    renderPending = true
  }

  fun setImageSources(value: List<ImageSourceDecision>) {
    if (imageSources == value) return
    imageSources = value
    dirtyFlags += DirtyFlag.RECREATE_SEGMENTS
    dirtyFlags += DirtyFlag.FORCE_HEIGHT
    renderPending = true
  }

  fun setDocumentRevision(value: Int) {
    if (documentRevision == value) return
    documentRevision = value
    ++currentRenderId
    renderPending = true
  }

  fun setMediaOverridesRevision(value: Int) {
    if (mediaOverridesRevision == value) return
    mediaOverridesRevision = value
    dirtyFlags += DirtyFlag.FORCE_HEIGHT
    renderPending = true
  }

  fun setEnableDocumentAssets(value: Boolean) {
    if (enableDocumentAssets == value) return
    enableDocumentAssets = value
    lastAssetManifest = null
    renderPending = true
  }

  fun setEnableMediaSlots(value: Boolean) {
    if (enableMediaSlots == value) return
    enableMediaSlots = value
    dirtyFlags += DirtyFlag.FORCE_HEIGHT
    renderPending = true
  }

  fun setMediaOverrides(value: List<MediaOverride>) {
    if (mediaOverrides == value) return
    mediaOverrides = value
    dirtyFlags += DirtyFlag.FORCE_HEIGHT
    renderPending = true
  }

  private val dirtyFlags = EnumSet.noneOf(DirtyFlag::class.java)
  var streamingAnimation: Boolean = false

  // used to force a Yoga re-measure when a block image resolves its box height
  var stateWrapper: StateWrapper? = null
  private var forceHeightRecalculationCounter = 0

  var tableStreamingMode: TableStreamingMode = TableStreamingMode.PROGRESSIVE
  var codeBlockStreamingMode: CodeBlockStreamingMode = CodeBlockStreamingMode.PROGRESSIVE
  private var renderPending: Boolean = false

  var currentMarkdown: String = ""
    private set

  var markdownStyle: StyleConfig? = null
    private set

  private var markdownStyleMap: ReadableMap? = null
  private var lastKnownFontScale: Float = context.resources.configuration.fontScale

  var md4cFlags: Md4cFlags = Md4cFlags.DEFAULT
    private set
  private var linkRegex: LinkRegexConfig? = null
  private var inlineCodeLinkRegex: LinkRegexConfig? = null
  private var isGFM: Boolean = true
  private var allowFontScaling: Boolean = true
  private var maxFontSizeMultiplier: Float = 0f
  private var imageRequestHeaders: Map<String, String> = emptyMap()
  private var selectable: Boolean = true
  private var selectionColor: Int? = null
  private var selectionHandleColor: Int? = null
  private var selectionMenuConfig = SelectionMenuConfig()
  private var accessibilityLabels = AccessibilityLabels()
  private var textBreakStrategy: String = BreakStrategyUtils.DEFAULT_STRATEGY

  private var onLinkPressCallback: ((String) -> Unit)? = null
  private var onLinkLongPressCallback: ((String) -> Unit)? = null
  private var onTaskListItemPressCallback: ((Int, Boolean, String) -> Unit)? = null
  private var onLatexErrorCallback: LatexErrorReporter? = null

  private val reportedLatexErrors = HashSet<String>()

  private val latexErrorReporter =
    LatexErrorReporter { source, message, displayMode ->
      val key = (if (displayMode) "B " else "I ") + source
      if (reportedLatexErrors.add(key)) {
        onLatexErrorCallback?.report(source, message, displayMode)
      }
    }
  private var contextMenuItemTexts: List<String> = emptyList()
  var onContextMenuItemPressCallback: ((itemText: String, selectedText: String, selectionStart: Int, selectionEnd: Int) -> Unit)? = null
  var spoilerOverlay: SpoilerOverlay = SpoilerOverlay.PARTICLES
    set(value) {
      if (field == value) return
      field = value
      segmentViews.filterIsInstance<EnrichedMarkdownInternalText>().forEach {
        it.spoilerOverlay = value
      }
    }
  var enableTaskListItemToggle: Boolean = true
    set(value) {
      if (field == value) return
      field = value
      segmentViews.filterIsInstance<EnrichedMarkdownInternalText>().forEach {
        it.enableTaskListItemToggle = value
      }
    }

  private val dynamicProps = DynamicBlockProps()

  var enableBlockContextMenu: Boolean
    get() = dynamicProps.enableBlockContextMenu
    set(value) {
      dynamicProps.enableBlockContextMenu = value
    }
  var enableCodeBlockPress: Boolean
    get() = dynamicProps.enableCodeBlockPress
    set(value) {
      dynamicProps.enableCodeBlockPress = value
    }

  init {
    segmentViewFactory = RootFactory()
  }

  fun setMarkdownContent(markdown: String) {
    if (currentMarkdown == markdown) return
    currentMarkdown = markdown
    ++currentRenderId
    renderPending = true
  }

  fun setMarkdownStyle(style: ReadableMap?) {
    markdownStyleMap = style
    val newConfig = style?.let { StyleConfig(it, context, allowFontScaling, maxFontSizeMultiplier) }
    newConfig?.imageRequestHeaders = imageRequestHeaders
    if (markdownStyle == newConfig) return
    markdownStyle = newConfig
    dirtyFlags += DirtyFlag.RECREATE_SEGMENTS
    dirtyFlags += DirtyFlag.FORCE_HEIGHT
    renderPending = true
  }

  fun setImageRequestHeaders(headers: Map<String, String>) {
    if (imageRequestHeaders == headers) return
    imageRequestHeaders = headers
    markdownStyle?.imageRequestHeaders = headers
    dirtyFlags += DirtyFlag.RECREATE_SEGMENTS
    renderPending = true
  }

  fun commitProps() {
    MeasurementStore.updateStreamingTableMode(id, tableStreamingMode)
    MeasurementStore.updateStreamingCodeBlockMode(id, codeBlockStreamingMode)
    MeasurementStore.updateFontScalingSettings(id, allowFontScaling, maxFontSizeMultiplier)
    if (renderPending) {
      renderPending = false
      scheduleRenderIfNeeded()
    }
  }

  override fun onConfigurationChanged(newConfig: Configuration) {
    super.onConfigurationChanged(newConfig)
    if (!allowFontScaling) return
    val newFontScale = newConfig.fontScale
    if (newFontScale != lastKnownFontScale) {
      lastKnownFontScale = newFontScale
      recreateStyleConfig()
      dirtyFlags += DirtyFlag.RECREATE_SEGMENTS
      dirtyFlags += DirtyFlag.FORCE_HEIGHT
      scheduleRenderIfNeeded()
    }
  }

  fun setLinkRegex(config: LinkRegexConfig?) {
    if (linkRegex == config) return
    linkRegex = config
    renderPending = true
  }

  fun setInlineCodeLinkRegex(config: LinkRegexConfig?) {
    if (inlineCodeLinkRegex == config) return
    inlineCodeLinkRegex = config
    renderPending = true
  }

  fun setMd4cFlags(flags: Md4cFlags) {
    if (md4cFlags == flags) return
    md4cFlags = flags
    renderPending = true
  }

  fun setIsGFM(value: Boolean) {
    if (isGFM == value) return
    isGFM = value
    renderPending = true
  }

  fun setAllowFontScaling(allow: Boolean) {
    if (allowFontScaling == allow) return
    allowFontScaling = allow
    MeasurementStore.updateFontScalingSettings(id, allowFontScaling, maxFontSizeMultiplier)
    recreateStyleConfig()
    dirtyFlags += DirtyFlag.RECREATE_SEGMENTS
    dirtyFlags += DirtyFlag.FORCE_HEIGHT
    renderPending = true
  }

  fun setMaxFontSizeMultiplier(multiplier: Float) {
    if (maxFontSizeMultiplier == multiplier) return
    maxFontSizeMultiplier = multiplier
    MeasurementStore.updateFontScalingSettings(id, allowFontScaling, maxFontSizeMultiplier)
    recreateStyleConfig()
    dirtyFlags += DirtyFlag.RECREATE_SEGMENTS
    dirtyFlags += DirtyFlag.FORCE_HEIGHT
    renderPending = true
  }

  fun setAllowTrailingMargin(allow: Boolean) {
    if (trailingMarginEnabled == allow) return
    trailingMarginEnabled = allow
    dirtyFlags += DirtyFlag.RECREATE_SEGMENTS
    dirtyFlags += DirtyFlag.FORCE_HEIGHT
    renderPending = true
  }

  fun setIsSelectable(value: Boolean) {
    if (selectable == value) return
    selectable = value
    segmentViews.filterIsInstance<EnrichedMarkdownInternalText>().forEach {
      it.setIsSelectable(value)
    }
  }

  fun setSelectionColor(color: Int?) {
    if (selectionColor == color) return
    selectionColor = color
    applySelectionColorsToSegments()
  }

  fun setSelectionHandleColor(color: Int?) {
    if (selectionHandleColor == color) return
    selectionHandleColor = color
    applySelectionColorsToSegments()
  }

  fun setTextBreakStrategy(strategy: String) {
    if (textBreakStrategy == strategy) return
    textBreakStrategy = strategy
    MeasurementStore.updateBreakStrategy(id, strategy)
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
      val resolved = BreakStrategyUtils.resolveBreakStrategy(strategy)
      segmentViews.filterIsInstance<EnrichedMarkdownInternalText>().forEach {
        it.breakStrategy = resolved
      }
    }
    dirtyFlags += DirtyFlag.FORCE_HEIGHT
    renderPending = true
  }

  private fun applySelectionColorsToSegments() {
    segmentViews.filterIsInstance<EnrichedMarkdownInternalText>().forEach {
      it.applySelectionColors(selectionColor, selectionHandleColor)
    }
  }

  fun setOnLinkPressCallback(callback: (String) -> Unit) {
    onLinkPressCallback = callback
  }

  fun setOnLinkLongPressCallback(callback: (String) -> Unit) {
    onLinkLongPressCallback = callback
  }

  fun setOnLatexErrorCallback(callback: LatexErrorReporter) {
    onLatexErrorCallback = callback
  }

  override var imagePressEnabled: Boolean = false
    private set

  override fun emitOnImagePress(
    url: String,
    altText: String,
  ) {
    emitImagePressEvent(url, altText)
  }

  fun setEnableImagePress(enabled: Boolean) {
    imagePressEnabled = enabled
  }

  fun setOnTaskListItemPressCallback(callback: ((taskIndex: Int, checked: Boolean, itemText: String) -> Unit)?) {
    onTaskListItemPressCallback = callback
  }

  fun setOnCopyPressCallback(callback: ((code: String, language: String) -> Unit)?) {
    dynamicProps.onCopyPress = callback
  }

  fun setOnCodeBlockPressCallback(callback: ((code: String, language: String) -> Unit)?) {
    dynamicProps.onCodeBlockPress = callback
  }

  fun setContextMenuItems(items: List<String>) {
    contextMenuItemTexts = items
    segmentViews.filterIsInstance<EnrichedMarkdownInternalText>().forEach {
      it.setContextMenuItems(items, ::forwardContextMenuItemPress)
    }
  }

  fun setSelectionMenuConfig(config: SelectionMenuConfig) {
    if (selectionMenuConfig == config) return
    selectionMenuConfig = config
    dynamicProps.copyLabel = config.copyLabel
    dynamicProps.copyAsMarkdownLabel = config.copyAsMarkdownLabel
    segmentViews.filterIsInstance<EnrichedMarkdownInternalText>().forEach {
      it.selectionMenuConfig = config
    }
  }

  fun setAccessibilityLabels(labels: AccessibilityLabels) {
    if (accessibilityLabels == labels) return
    accessibilityLabels = labels
    segmentViews.filterIsInstance<EnrichedMarkdownInternalText>().forEach {
      it.accessibilityLabels = labels
    }
    segmentViews.filterIsInstance<TableContainerView>().forEach {
      it.accessibilityLabels = labels
    }
    mathContainerClass?.let { mathClass ->
      segmentViews.filter { mathClass.isInstance(it) }.forEach { view ->
        runCatching {
          mathClass
            .getMethod("setAccessibilityLabels", AccessibilityLabels::class.java)
            .invoke(view, labels)
        }
      }
    }
  }

  private fun forwardContextMenuItemPress(
    itemText: String,
    selectedText: String,
    selectionStart: Int,
    selectionEnd: Int,
  ) {
    onContextMenuItemPressCallback?.invoke(itemText, selectedText, selectionStart, selectionEnd)
  }

  private fun recreateStyleConfig() {
    markdownStyleMap?.let {
      markdownStyle =
        StyleConfig(it, context, allowFontScaling, maxFontSizeMultiplier).also { config ->
          config.imageRequestHeaders = imageRequestHeaders
        }
    }
  }

  private fun scheduleRenderIfNeeded() {
    if (currentMarkdown.isNotEmpty()) {
      scheduleRender()
    } else {
      applyEmptyDocument(documentRevision)
    }
  }

  private fun scheduleRender() {
    val style = markdownStyle ?: return
    val markdown = currentMarkdown.takeIf { it.isNotEmpty() } ?: return
    val isStreaming = streamingAnimation
    val tableMode = tableStreamingMode
    val codeBlockMode = codeBlockStreamingMode

    val sourcesEnabled = enableImageSourceResolution && isGFM
    val sourcesRevision = imageSourcesRevision
    val sourcesContinuityStart = imageSourcesContinuityStart
    val sources = imageSources
    val revision = documentRevision
    val assetEventsEnabled = enableDocumentAssets
    val slotsEnabled = enableMediaSlots
    val overrideRevision = mediaOverridesRevision
    val overrides = mediaOverrides
    val flags = md4cFlags
    val gfm = isGFM
    val textLinkRegex = linkRegex
    val codeLinkRegex = inlineCodeLinkRegex
    val renderId = ++currentRenderId

    executor.execute {
      try {
        val filtered =
          if (isStreaming) {
            StreamingMarkdownFilter.renderableMarkdownForStreaming(markdown, tableMode, codeBlockMode)
          } else {
            null
          }
        val renderableMarkdown = filtered?.markdown ?: markdown
        val hasPendingCodeBlock = filtered?.endsInsideOpenCodeFence ?: false

        if (renderableMarkdown.isEmpty()) {
          postToMain(renderId) { applyEmptyDocument(revision) }
          return@execute
        }

        val ast =
          parser.parseMarkdown(renderableMarkdown, flags, gfm, textLinkRegex, codeLinkRegex) ?: run {
            postToMain(renderId) { applyEmptyDocument(revision) }
            return@execute
          }

        val sourceAST = withImageSources(ast, sourcesEnabled, revision, sourcesRevision, sourcesContinuityStart, sources)
        val assets = DocumentAssets.collect(sourceAST)
        val mediaSlots = mediaSlotsForDocument(assets, slotsEnabled, revision, overrideRevision, overrides)
        val segments = splitASTIntoSegments(sourceAST, mediaSlots, assets)
        val renderedSegments =
          MarkdownSegmentRenderer.render(
            segments,
            style,
            context,
            onLinkPressCallback,
            onLinkLongPressCallback,
            onLatexError = latexErrorReporter,
          )

        postToMain(renderId) {
          if (revision != documentRevision) return@postToMain
          acceptedRevision = revision
          acceptedAssets = assets.assets
          val forceHeight = DirtyFlag.FORCE_HEIGHT in dirtyFlags
          applyRenderedSegments(renderedSegments, hasPendingCodeBlock)
          if (assetEventsEnabled) publishAssets(revision, assets.assets)
          publishMediaFrames()
          if (forceHeight) onImageLayoutChanged()
        }
      } catch (e: Exception) {
        Log.e(TAG, "Render failed", e)
        postToMain(renderId) { applyEmptyDocument(revision) }
      }
    }
  }

  // Trailing code block whose closing fence hasn't streamed in yet, if any.
  private var pendingCodeBlockSegment: RenderedSegment.CodeBlock? = null

  private fun applyRenderedSegments(
    renderedSegments: List<RenderedSegment>,
    hasPendingCodeBlock: Boolean,
  ) {
    pendingCodeBlockSegment =
      if (hasPendingCodeBlock) renderedSegments.lastOrNull() as? RenderedSegment.CodeBlock else null

    val reset = DirtyFlag.RECREATE_SEGMENTS in dirtyFlags
    val forceHeight = DirtyFlag.FORCE_HEIGHT in dirtyFlags
    dirtyFlags.clear()

    val topologyChanged = applySegments(renderedSegments, reset)

    // A just-closed block has unchanged content, so the reconciler reuses it
    // without an update; sync pending here to trigger its deferred highlight.
    segmentViews.forEachIndexed { index, view ->
      if (view is CodeBlockContainerView) {
        view.pending = pendingCodeBlockSegment != null && index == segmentViews.size - 1
      }
    }

    if (width > 0) {
      val heightBefore = computeSegmentsTotalHeight()
      layoutSegments()
      val heightAfter = computeSegmentsTotalHeight()

      if (forceHeight || topologyChanged || heightBefore != heightAfter) {
        MeasurementStore.invalidate(id)
        requestLayout()
      }
    }
  }

  private fun isMathContainerView(view: View): Boolean = mathContainerClass?.isInstance(view) == true

  private fun isVideoContainerView(view: View): Boolean = videoContainerClass?.isInstance(view) == true

  private fun segmentViewConfig(): SegmentViewConfig =
    SegmentViewConfig(
      context = context,
      style = markdownStyle!!,
      allowFontScaling = allowFontScaling,
      maxFontSizeMultiplier = maxFontSizeMultiplier,
      accessibilityLabels = accessibilityLabels,
      selectionMenuConfig = selectionMenuConfig,
      textBreakStrategy = textBreakStrategy,
      selectable = selectable,
      selectionColor = selectionColor,
      selectionHandleColor = selectionHandleColor,
      contextMenuItemTexts = contextMenuItemTexts,
      dynamicProps = dynamicProps,
      onLinkPress = onLinkPressCallback,
      onLinkLongPress = onLinkLongPressCallback,
      onTaskListItemPress = onTaskListItemPressCallback,
      onContextMenuItemPress = ::forwardContextMenuItemPress,
      onLatexError = latexErrorReporter,
    )

  /**
   * Root factory: builds child views through the shared creators, then layers on
   * root-only concerns (spoiler overlay mode, task-list toggle, streaming tail /
   * fade-in animation, and the pending code block sync for the open trailing
   * fence).
   */
  private inner class RootFactory : SegmentViewFactory {
    override fun matchesKind(
      view: View,
      segment: RenderedSegment,
    ): Boolean =
      when (segment) {
        is RenderedSegment.Text -> view is EnrichedMarkdownInternalText
        is RenderedSegment.Table -> view is TableContainerView
        is RenderedSegment.Math -> isMathContainerView(view)
        is RenderedSegment.CodeBlock -> view is CodeBlockContainerView
        is RenderedSegment.Blockquote -> view is BlockquoteContainerView
        is RenderedSegment.Video -> if (segment.mediaSlot != null) view is MediaSlotView else isVideoContainerView(view)
      }

    override fun createView(segment: RenderedSegment): View {
      val config = segmentViewConfig()
      return when (segment) {
        is RenderedSegment.Text -> {
          SegmentViewCreators.createTextView(segment, config).apply {
            spoilerOverlay = this@EnrichedMarkdown.spoilerOverlay
            enableTaskListItemToggle = this@EnrichedMarkdown.enableTaskListItemToggle
          }
        }

        is RenderedSegment.Table -> {
          SegmentViewCreators.createTableView(segment, config)
        }

        is RenderedSegment.Math -> {
          SegmentViewCreators.createMathView(segment, config)
        }

        is RenderedSegment.CodeBlock -> {
          SegmentViewCreators.createCodeBlockView(segment, config).apply {
            pending = segment === pendingCodeBlockSegment
          }
        }

        is RenderedSegment.Blockquote -> {
          SegmentViewCreators.createBlockquoteView(segment, config)
        }

        is RenderedSegment.Video -> {
          SegmentViewCreators.createVideoView(segment, config)
        }
      }
    }

    override fun updateView(
      view: View,
      segment: RenderedSegment,
    ) {
      when (segment) {
        is RenderedSegment.Text -> {
          val textView = view as EnrichedMarkdownInternalText
          val tailStart = textView.text?.length ?: 0
          SegmentViewCreators.updateTextView(textView, segment)
          animateTextViewTail(textView, tailStart)
        }

        is RenderedSegment.Table -> {
          val tableView = view as TableContainerView
          val previousRowCount = tableView.rowCount
          tableView.applyTableNode(segment.node)
          if (streamingAnimation && !isReducedMotionEnabled(context)) {
            tableView.animateNewRows(previousRowCount, BLOCK_FADE_DURATION_MS)
          }
        }

        is RenderedSegment.Math -> {
          SegmentViewCreators.updateMathView(view, segment)
        }

        is RenderedSegment.CodeBlock -> {
          (view as CodeBlockContainerView).apply {
            pending = segment === pendingCodeBlockSegment
            applyCodeBlockNode(segment.node)
          }
        }

        is RenderedSegment.Blockquote -> {
          (view as BlockquoteContainerView).applyBlockquoteNode(segment.node, segment.mediaSlots, segment.assets)
        }

        is RenderedSegment.Video -> {
          SegmentViewCreators.updateVideoView(view, segment)
        }
      }
    }

    override fun animateNewView(
      view: View,
      segment: RenderedSegment,
    ) {
      if (!streamingAnimation) return
      when (segment) {
        is RenderedSegment.Text -> animateTextViewTail(view as EnrichedMarkdownInternalText, 0)

        is RenderedSegment.Table,
        is RenderedSegment.Math,
        is RenderedSegment.CodeBlock,
        is RenderedSegment.Blockquote,
        is RenderedSegment.Video,
        -> animateBlockViewFadeIn(view)
      }
    }
  }

  private fun animateTextViewTail(
    view: EnrichedMarkdownInternalText,
    tailStart: Int,
  ) {
    if (!streamingAnimation) return
    val textLength = view.text?.length ?: 0
    if (textLength <= tailStart) return
    TailFadeInAnimator(view).animate(tailStart, textLength)
  }

  private fun animateBlockViewFadeIn(view: View) {
    if (!streamingAnimation) return
    if (isReducedMotionEnabled(context)) return
    view.alpha = 0f
    view
      .animate()
      .alpha(1f)
      .setDuration(BLOCK_FADE_DURATION_MS)
      .start()
  }

  private fun postToMain(
    renderId: Long,
    action: () -> Unit,
  ) {
    mainHandler.post {
      if (renderId == currentRenderId) action()
    }
  }

  override fun onLayout(
    changed: Boolean,
    l: Int,
    t: Int,
    r: Int,
    b: Int,
  ) {
    layoutSegments()
    if (acceptedRevision == documentRevision) publishAssets(acceptedRevision, acceptedAssets)
    publishMediaFrames()
  }

  fun onImageLayoutChanged() {
    if (width > 0) {
      layoutSegments()
      requestLayout()
    }
    MeasurementStore.invalidate(id)
    val wrapper = stateWrapper ?: return
    val state = Arguments.createMap()
    state.putInt("forceHeightRecalculationCounter", ++forceHeightRecalculationCounter)
    wrapper.updateState(state)
  }

  private fun applyEmptyDocument(revision: Int) {
    if (revision != documentRevision) return
    acceptedRevision = revision
    acceptedAssets = emptyList()
    applyRenderedSegments(emptyList(), false)
    publishAssets(revision, emptyList())
    publishMediaFrames()
    onImageLayoutChanged()
  }

  private fun publishAssets(
    revision: Int,
    assets: List<DocumentAsset>,
  ) {
    if (!enableDocumentAssets) return
    val manifest = revision to assets
    if (lastAssetManifest == manifest) return
    if (emitMediaEvent(this, "onDocumentAssets", documentAssetsEventData(revision, assets))) {
      lastAssetManifest = manifest
    }
  }

  private fun publishMediaFrames() {
    if (acceptedRevision != documentRevision || width <= 0) return
    val slots = mediaSlotFrames()
    val key =
      "$acceptedRevision:" +
        slots.joinToString(";") {
          "${it.id},${it.x},${it.y},${it.width},${it.height}"
        }
    if (lastMediaFrames == key) return
    val frames = Arguments.createArray()
    slots.forEach { view ->
      frames.pushMap(
        Arguments.createMap().apply {
          putString("id", view.id)
          putDouble("x", PixelUtil.toDIPFromPixel(view.x.toFloat()).toDouble())
          putDouble("y", PixelUtil.toDIPFromPixel(view.y.toFloat()).toDouble())
          putDouble("width", PixelUtil.toDIPFromPixel(view.width.toFloat()).toDouble())
          putDouble("height", PixelUtil.toDIPFromPixel(view.height.toFloat()).toDouble())
        },
      )
    }
    val data =
      Arguments.createMap().apply {
        putInt("revision", acceptedRevision)
        putArray("frames", frames)
      }
    if (emitMediaEvent(this, "onMediaLayout", data)) lastMediaFrames = key
  }

  fun cleanup() {
    ++currentRenderId
    mainHandler.removeCallbacksAndMessages(null)
    executor.shutdownNow()
  }

  companion object {
    private const val TAG = "EnrichedMarkdown"
    private const val BLOCK_FADE_DURATION_MS = 200L
  }
}
