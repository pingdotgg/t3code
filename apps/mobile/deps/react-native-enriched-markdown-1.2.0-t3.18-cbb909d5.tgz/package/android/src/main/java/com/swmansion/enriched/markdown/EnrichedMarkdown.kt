package com.swmansion.enriched.markdown

import android.content.Context
import android.content.res.Configuration
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.View
import androidx.core.view.children
import com.facebook.react.bridge.Arguments
import com.facebook.react.bridge.ReadableMap
import com.facebook.react.uimanager.StateWrapper
import com.swmansion.enriched.markdown.accessibility.AccessibilityLabels
import com.swmansion.enriched.markdown.math.LatexErrorReporter
import com.swmansion.enriched.markdown.parser.Md4cFlags
import com.swmansion.enriched.markdown.parser.Parser
import com.swmansion.enriched.markdown.segments.BlockSlotSegmentView
import com.swmansion.enriched.markdown.segments.BlockquoteContainerView
import com.swmansion.enriched.markdown.segments.CodeBlockContainerView
import com.swmansion.enriched.markdown.segments.ContainerNodeView
import com.swmansion.enriched.markdown.segments.DynamicBlockProps
import com.swmansion.enriched.markdown.segments.MarkdownSegmentRenderer
import com.swmansion.enriched.markdown.segments.RenderedSegment
import com.swmansion.enriched.markdown.segments.SegmentViewConfig
import com.swmansion.enriched.markdown.segments.SegmentViewCreators
import com.swmansion.enriched.markdown.segments.SegmentViewFactory
import com.swmansion.enriched.markdown.segments.TableContainerView
import com.swmansion.enriched.markdown.segments.splitASTIntoSegments
import com.swmansion.enriched.markdown.slots.BlockSlotLayer
import com.swmansion.enriched.markdown.slots.BlockSlotRevealController
import com.swmansion.enriched.markdown.slots.BlockSlotRevealTarget
import com.swmansion.enriched.markdown.slots.EnrichedMarkdownBlockSlotView
import com.swmansion.enriched.markdown.slots.SlotPlacements
import com.swmansion.enriched.markdown.spoiler.SpoilerOverlay
import com.swmansion.enriched.markdown.styles.ImageSourceOverride
import com.swmansion.enriched.markdown.styles.LinkPillContent
import com.swmansion.enriched.markdown.styles.StyleConfig
import com.swmansion.enriched.markdown.utils.common.BreakStrategyUtils
import com.swmansion.enriched.markdown.utils.common.CodeBlockStreamingMode
import com.swmansion.enriched.markdown.utils.common.LinkRegexConfig
import com.swmansion.enriched.markdown.utils.common.MediaStreamingMode
import com.swmansion.enriched.markdown.utils.common.StreamingMarkdownFilter
import com.swmansion.enriched.markdown.utils.common.TableStreamingMode
import com.swmansion.enriched.markdown.utils.common.animatorDurationScale
import com.swmansion.enriched.markdown.utils.common.isReducedMotionEnabled
import com.swmansion.enriched.markdown.utils.text.TailFadeInAnimator
import com.swmansion.enriched.markdown.utils.text.view.ImagePressHost
import com.swmansion.enriched.markdown.utils.text.view.SelectionMenuConfig
import com.swmansion.enriched.markdown.utils.text.view.TextPressHost
import com.swmansion.enriched.markdown.utils.text.view.applySelectionColors
import com.swmansion.enriched.markdown.utils.text.view.emitImagePressEvent
import com.swmansion.enriched.markdown.utils.text.view.emitTextPressEvent
import java.util.EnumSet
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

class EnrichedMarkdown(
  context: Context,
) : ContainerNodeView(context),
  ImagePressHost,
  TextPressHost {
  private enum class DirtyFlag {
    RECREATE_SEGMENTS,
    FORCE_HEIGHT,

    // Yoga already measured with inputs that changed after (the wrapped code
    // blocks a prop reset cleared), so it has to be asked to measure again.
    REMEASURE,
  }

  private val parser = Parser.shared
  private val mainHandler = Handler(Looper.getMainLooper())
  private val executor: ExecutorService = Executors.newSingleThreadExecutor()
  private val mathContainerClass: Class<*>? by lazy { SegmentViewCreators.mathContainerClass() }
  private val videoContainerClass: Class<*>? by lazy { SegmentViewCreators.videoContainerClass() }

  private var currentRenderId = 0L

  // Set when React Native drops the view for good. Detaching from the window is
  // not disposal: a view renders before its first attach and while detached.
  private var isDisposed = false
  private val dirtyFlags = EnumSet.noneOf(DirtyFlag::class.java)
  var streamingAnimation: Boolean = false
    set(value) {
      if (field == value) return
      field = value
      // The streaming filter only applies while this is on, so re-render to
      // show or hide the content it holds back.
      dirtyFlags += DirtyFlag.FORCE_HEIGHT
      renderPending = true
      if (!value) {
        blockSlotReveal.cancel()
        applyBlockSlotReveal()
        if (width > 0) layoutSegments()
      }
    }

  // used to force a Yoga re-measure when a block image resolves its box height
  var stateWrapper: StateWrapper? = null
  private var forceHeightRecalculationCounter = 0

  var tableStreamingMode: TableStreamingMode = TableStreamingMode.PROGRESSIVE
    set(value) {
      if (field == value) return
      field = value
      dirtyFlags += DirtyFlag.FORCE_HEIGHT
      renderPending = true
    }
  var codeBlockStreamingMode: CodeBlockStreamingMode = CodeBlockStreamingMode.PROGRESSIVE
    set(value) {
      if (field == value) return
      field = value
      dirtyFlags += DirtyFlag.FORCE_HEIGHT
      renderPending = true
    }
  var mediaStreamingMode: MediaStreamingMode = MediaStreamingMode.PROGRESSIVE
    set(value) {
      if (field == value) return
      field = value
      dirtyFlags += DirtyFlag.FORCE_HEIGHT
      renderPending = true
    }
  private var renderPending: Boolean = false

  var currentMarkdown: String = ""
    private set

  var selectionClipboardConfig =
    com.swmansion.enriched.markdown.utils.text.view
      .SelectionClipboardConfig()
    private set

  fun setSelectionClipboardConfig(value: String?) {
    selectionClipboardConfig =
      com.swmansion.enriched.markdown.utils.text.view.SelectionClipboardConfig
        .parse(value)
    markdownStyle?.selectionClipboard = selectionClipboardConfig
  }

  var markdownStyle: StyleConfig? = null
    private set

  private var markdownStyleMap: ReadableMap? = null
  private var lastKnownFontScale: Float = context.resources.configuration.fontScale

  var md4cFlags: Md4cFlags = Md4cFlags.DEFAULT
    private set
  private var linkRegex: LinkRegexConfig? = null
  private var inlineCodeLinkRegex: LinkRegexConfig? = null
  private var isGFM: Boolean = true
  private var allowFontScaling: Boolean = true
  private var maxFontSizeMultiplier: Float = 0f
  private var imageRequestHeaders: Map<String, String> = emptyMap()
  private var imageSourceOverrides: Map<String, ImageSourceOverride> = emptyMap()
  private var linkPillContent: Map<String, LinkPillContent> = emptyMap()

  // Fabric children (the React slot views) live here, above the segments, so the
  // segment reconciler's child indices stay its own. Fabric positions them.
  val slotLayer = BlockSlotLayer(context)

  // From the shadow node's state: the placed slot children's ids and heights (px).
  private var activeBlockSlotIds: Set<String> = emptySet()
  private var blockSlotHeights: Map<String, Int> = emptyMap()
  private val blockSlotReveal =
    BlockSlotRevealController(durationScale = { animatorDurationScale(context) }) { stepBlockSlotReveal() }
  private var selectable: Boolean = true
  private var selectionColor: Int? = null
  private var selectionHandleColor: Int? = null
  private var selectionMenuConfig = SelectionMenuConfig()
  private var accessibilityLabels = AccessibilityLabels()
  private var textBreakStrategy: String = BreakStrategyUtils.DEFAULT_STRATEGY

  private var onLinkPressCallback: ((String) -> Unit)? = null
  private var onLinkLongPressCallback: ((String) -> Unit)? = null
  private var onTaskListItemPressCallback: ((Int, Boolean, String) -> Unit)? = null
  private var onLatexErrorCallback: LatexErrorReporter? = null

  private val reportedLatexErrors = HashSet<String>()

  private val latexErrorReporter =
    LatexErrorReporter { source, message, displayMode ->
      val key = (if (displayMode) "B " else "I ") + source
      if (reportedLatexErrors.add(key)) {
        onLatexErrorCallback?.report(source, message, displayMode)
      }
    }
  private var contextMenuItemTexts: List<String> = emptyList()
  var onContextMenuItemPressCallback: ((itemText: String, selectedText: String, selectionStart: Int, selectionEnd: Int) -> Unit)? = null
  var spoilerOverlay: SpoilerOverlay = SpoilerOverlay.PARTICLES
    set(value) {
      if (field == value) return
      field = value
      segmentViews.filterIsInstance<EnrichedMarkdownInternalText>().forEach {
        it.spoilerOverlay = value
      }
    }
  var enableTaskListItemToggle: Boolean = true
    set(value) {
      if (field == value) return
      field = value
      segmentViews.filterIsInstance<EnrichedMarkdownInternalText>().forEach {
        it.enableTaskListItemToggle = value
      }
    }

  private val dynamicProps = DynamicBlockProps()

  var enableBlockContextMenu: Boolean
    get() = dynamicProps.enableBlockContextMenu
    set(value) {
      dynamicProps.enableBlockContextMenu = value
    }
  var enableCodeBlockPress: Boolean
    get() = dynamicProps.enableCodeBlockPress
    set(value) {
      dynamicProps.enableCodeBlockPress = value
    }

  private val codeBlockWrapState =
    CodeBlockWrapState(viewTag = { id }, codeBlockViews = ::codeBlockViews, onHeightChanged = ::onImageLayoutChanged)

  var enableCodeBlockWrapToggle: Boolean
    get() = codeBlockWrapState.enabled
    set(value) {
      if (codeBlockWrapState.setEnabled(value)) onImageLayoutChanged()
    }

  init {
    segmentViewFactory = RootFactory()
    // The layer stays the last child (applySegments places segments in front of
    // it), so it draws above them and touch lookup reaches the slots first.
    addView(slotLayer, LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT))
    slotLayer.setOnHierarchyChangeListener(
      object : OnHierarchyChangeListener {
        // A child mounted mid grow-in is placed and clipped before it draws.
        override fun onChildViewAdded(
          parent: View?,
          child: View?,
        ) {
          applyBlockSlotReveal()
        }

        override fun onChildViewRemoved(
          parent: View?,
          child: View?,
        ) = Unit
      },
    )
  }

  // The slot layer spans the whole host, so the default order, by position,
  // would read every React replacement before the text above it.
  override fun slotViewsForAccessibility(): Map<String, View> =
    slotLayer.children.filterIsInstance<EnrichedMarkdownBlockSlotView>().associateBy { it.slotId }

  // isTaskToggle marks a checkbox flip rendered locally ahead of the prop; it
  // moves no code block, so it skips the wrap state's reset rule.
  fun setMarkdownContent(
    markdown: String,
    isTaskToggle: Boolean = false,
  ) {
    // The shadow node measures the new markdown before this setter runs, still
    // with the old wrapped set, so a reset needs Yoga to measure again.
    if (!isTaskToggle && codeBlockWrapState.onMarkdownProp(markdown, currentMarkdown)) {
      dirtyFlags += DirtyFlag.REMEASURE
    }
    if (currentMarkdown == markdown) return
    currentMarkdown = markdown
    renderPending = true
  }

  fun setMarkdownStyle(style: ReadableMap?) {
    markdownStyleMap = style
    val newConfig = style?.let { StyleConfig(it, context, allowFontScaling, maxFontSizeMultiplier) }
    newConfig?.selectionClipboard = selectionClipboardConfig
    newConfig?.imageRequestHeaders = imageRequestHeaders
    newConfig?.imageSourceOverrides = imageSourceOverrides
    newConfig?.linkPillContent = linkPillContent
    if (markdownStyle == newConfig) return
    markdownStyle = newConfig
    dirtyFlags += DirtyFlag.RECREATE_SEGMENTS
    dirtyFlags += DirtyFlag.FORCE_HEIGHT
    renderPending = true
  }

  fun setImageRequestHeaders(headers: Map<String, String>) {
    if (imageRequestHeaders == headers) return
    imageRequestHeaders = headers
    markdownStyle?.imageRequestHeaders = headers
    dirtyFlags += DirtyFlag.RECREATE_SEGMENTS
    renderPending = true
  }

  fun setImageSources(sources: Map<String, ImageSourceOverride>) {
    if (imageSourceOverrides == sources) return
    imageSourceOverrides = sources
    markdownStyle?.imageSourceOverrides = sources
    dirtyFlags += DirtyFlag.RECREATE_SEGMENTS
    renderPending = true
  }

  /**
   * The shadow node's `slotPlacements` state: which slot children exist and how
   * tall the placed ones are. New ids need a render that claims their blocks; new
   * heights only restack the segments (Yoga already measured with them).
   */
  fun applySlotPlacements(state: ReadableMap?) {
    val placements = SlotPlacements.from(state)
    blockSlotHeights = placements.heightsPx
    blockSlotReveal.keepSlotIds(placements.ids)
    if (updateBlockSlotHeights(placements.heightsPx) && width > 0) {
      layoutSegments()
      requestLayout()
    }
    // Only placed children stand in for their blocks: an unplaced one (its block
    // is gone, or measurement fell back) leaves the native block in place.
    if (activeBlockSlotIds != placements.placed) {
      activeBlockSlotIds = placements.placed
      // Rendered now, in this commit, not in commitProps nor one executor hop later.
      renderPending = false
      renderSynchronously()
    }
  }

  fun setLinkPillContent(content: Map<String, LinkPillContent>) {
    if (linkPillContent == content) return
    linkPillContent = content
    markdownStyle?.linkPillContent = content
    // A label can change the pill's width and so the wrapped height.
    dirtyFlags += DirtyFlag.RECREATE_SEGMENTS
    dirtyFlags += DirtyFlag.FORCE_HEIGHT
    renderPending = true
  }

  fun commitProps() {
    if (isDisposed) return
    MeasurementStore.updateFontScalingSettings(id, allowFontScaling, maxFontSizeMultiplier)
    if (renderPending) {
      renderPending = false
      scheduleRenderIfNeeded()
    }
  }

  override fun onConfigurationChanged(newConfig: Configuration) {
    super.onConfigurationChanged(newConfig)
    if (!allowFontScaling) return
    val newFontScale = newConfig.fontScale
    if (newFontScale != lastKnownFontScale) {
      lastKnownFontScale = newFontScale
      recreateStyleConfig()
      dirtyFlags += DirtyFlag.RECREATE_SEGMENTS
      dirtyFlags += DirtyFlag.FORCE_HEIGHT
      scheduleRenderIfNeeded()
    }
  }

  fun setLinkRegex(config: LinkRegexConfig?) {
    if (linkRegex == config) return
    linkRegex = config
    renderPending = true
  }

  fun setInlineCodeLinkRegex(config: LinkRegexConfig?) {
    if (inlineCodeLinkRegex == config) return
    inlineCodeLinkRegex = config
    renderPending = true
  }

  fun setMd4cFlags(flags: Md4cFlags) {
    if (md4cFlags == flags) return
    md4cFlags = flags
    renderPending = true
  }

  fun setIsGFM(value: Boolean) {
    if (isGFM == value) return
    isGFM = value
    renderPending = true
  }

  fun setAllowFontScaling(allow: Boolean) {
    if (allowFontScaling == allow) return
    allowFontScaling = allow
    MeasurementStore.updateFontScalingSettings(id, allowFontScaling, maxFontSizeMultiplier)
    recreateStyleConfig()
    dirtyFlags += DirtyFlag.RECREATE_SEGMENTS
    dirtyFlags += DirtyFlag.FORCE_HEIGHT
    renderPending = true
  }

  fun setMaxFontSizeMultiplier(multiplier: Float) {
    if (maxFontSizeMultiplier == multiplier) return
    maxFontSizeMultiplier = multiplier
    MeasurementStore.updateFontScalingSettings(id, allowFontScaling, maxFontSizeMultiplier)
    recreateStyleConfig()
    dirtyFlags += DirtyFlag.RECREATE_SEGMENTS
    dirtyFlags += DirtyFlag.FORCE_HEIGHT
    renderPending = true
  }

  fun setAllowTrailingMargin(allow: Boolean) {
    if (trailingMarginEnabled == allow) return
    trailingMarginEnabled = allow
    dirtyFlags += DirtyFlag.RECREATE_SEGMENTS
    dirtyFlags += DirtyFlag.FORCE_HEIGHT
    renderPending = true
  }

  fun setIsSelectable(value: Boolean) {
    if (selectable == value) return
    selectable = value
    segmentViews.filterIsInstance<EnrichedMarkdownInternalText>().forEach {
      it.setIsSelectable(value)
    }
  }

  fun setSelectionColor(color: Int?) {
    if (selectionColor == color) return
    selectionColor = color
    applySelectionColorsToSegments()
  }

  fun setSelectionHandleColor(color: Int?) {
    if (selectionHandleColor == color) return
    selectionHandleColor = color
    applySelectionColorsToSegments()
  }

  fun setTextBreakStrategy(strategy: String) {
    if (textBreakStrategy == strategy) return
    textBreakStrategy = strategy
    MeasurementStore.updateBreakStrategy(id, strategy)
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
      val resolved = BreakStrategyUtils.resolveBreakStrategy(strategy)
      segmentViews.filterIsInstance<EnrichedMarkdownInternalText>().forEach {
        it.breakStrategy = resolved
      }
    }
    dirtyFlags += DirtyFlag.FORCE_HEIGHT
    renderPending = true
  }

  private fun applySelectionColorsToSegments() {
    segmentViews.filterIsInstance<EnrichedMarkdownInternalText>().forEach {
      it.applySelectionColors(selectionColor, selectionHandleColor)
    }
  }

  fun setOnLinkPressCallback(callback: (String) -> Unit) {
    onLinkPressCallback = callback
  }

  fun setOnLinkLongPressCallback(callback: (String) -> Unit) {
    onLinkLongPressCallback = callback
  }

  fun setOnLatexErrorCallback(callback: LatexErrorReporter) {
    onLatexErrorCallback = callback
  }

  override var imagePressEnabled: Boolean = false
    private set

  override fun emitOnImagePress(
    url: String,
    altText: String,
  ) {
    emitImagePressEvent(url, altText)
  }

  fun setEnableImagePress(enabled: Boolean) {
    imagePressEnabled = enabled
  }

  override var textPressEnabled: Boolean = false
    private set

  override fun emitOnTextPress(
    index: Int,
    text: String,
  ) {
    emitTextPressEvent(index, text)
  }

  fun setEnableTextPress(enabled: Boolean) {
    textPressEnabled = enabled
  }

  fun setOnTaskListItemPressCallback(callback: ((taskIndex: Int, checked: Boolean, itemText: String) -> Unit)?) {
    onTaskListItemPressCallback = callback
  }

  fun setOnCopyPressCallback(callback: ((code: String, language: String) -> Unit)?) {
    dynamicProps.onCopyPress = callback
  }

  fun setOnCodeBlockPressCallback(callback: ((code: String, language: String) -> Unit)?) {
    dynamicProps.onCodeBlockPress = callback
  }

  fun setContextMenuItems(items: List<String>) {
    contextMenuItemTexts = items
    segmentViews.filterIsInstance<EnrichedMarkdownInternalText>().forEach {
      it.setContextMenuItems(items, ::forwardContextMenuItemPress)
    }
  }

  fun setSelectionMenuConfig(config: SelectionMenuConfig) {
    if (selectionMenuConfig == config) return
    selectionMenuConfig = config
    dynamicProps.copyLabel = config.copyLabel
    dynamicProps.copyAsMarkdownLabel = config.copyAsMarkdownLabel
    segmentViews.filterIsInstance<EnrichedMarkdownInternalText>().forEach {
      it.selectionMenuConfig = config
    }
  }

  fun setAccessibilityLabels(labels: AccessibilityLabels) {
    if (accessibilityLabels == labels) return
    accessibilityLabels = labels
    segmentViews.filterIsInstance<EnrichedMarkdownInternalText>().forEach {
      it.accessibilityLabels = labels
    }
    segmentViews.filterIsInstance<TableContainerView>().forEach {
      it.accessibilityLabels = labels
    }
    codeBlockViews().forEach {
      it.accessibilityLabels = labels
    }
    mathContainerClass?.let { mathClass ->
      segmentViews.filter { mathClass.isInstance(it) }.forEach { view ->
        runCatching {
          mathClass
            .getMethod("setAccessibilityLabels", AccessibilityLabels::class.java)
            .invoke(view, labels)
        }
      }
    }
  }

  private fun forwardContextMenuItemPress(
    itemText: String,
    selectedText: String,
    selectionStart: Int,
    selectionEnd: Int,
  ) {
    onContextMenuItemPressCallback?.invoke(itemText, selectedText, selectionStart, selectionEnd)
  }

  private fun recreateStyleConfig() {
    markdownStyleMap?.let {
      markdownStyle =
        StyleConfig(it, context, allowFontScaling, maxFontSizeMultiplier).also { config ->
          config.selectionClipboard = selectionClipboardConfig
          config.imageRequestHeaders = imageRequestHeaders
          config.imageSourceOverrides = imageSourceOverrides
          config.linkPillContent = linkPillContent
        }
    }
  }

  private fun scheduleRenderIfNeeded() {
    if (currentMarkdown.isNotEmpty()) scheduleRender()
  }

  // Everything one render needs, captured on the main thread.
  private class RenderJob(
    val style: StyleConfig,
    val markdown: String,
    val isStreaming: Boolean,
    val tableMode: TableStreamingMode,
    val codeBlockMode: CodeBlockStreamingMode,
    val mediaMode: MediaStreamingMode,
    val textLinkRegex: LinkRegexConfig?,
    val codeLinkRegex: LinkRegexConfig?,
    val slotIds: Set<String>,
    val annotateImages: Boolean,
  )

  private fun renderJob(): RenderJob? {
    val style = markdownStyle ?: return null
    val markdown = currentMarkdown.takeIf { it.isNotEmpty() } ?: return null
    return RenderJob(
      style,
      markdown,
      streamingAnimation,
      tableStreamingMode,
      codeBlockStreamingMode,
      mediaStreamingMode,
      linkRegex,
      inlineCodeLinkRegex,
      activeBlockSlotIds,
      imageSourceOverrides.isNotEmpty(),
    )
  }

  // Parses and renders off the main thread's state; safe on any thread.
  private fun runRenderJob(job: RenderJob): Pair<List<RenderedSegment>, Boolean> {
    val filtered =
      if (job.isStreaming) {
        StreamingMarkdownFilter.renderableMarkdownForStreaming(job.markdown, job.tableMode, job.codeBlockMode, job.mediaMode)
      } else {
        null
      }
    val renderableMarkdown = filtered?.markdown ?: job.markdown
    val hasPendingCodeBlock = filtered?.endsInsideOpenCodeFence ?: false
    if (renderableMarkdown.isEmpty()) return emptyList<RenderedSegment>() to false

    val ast =
      parser.parseMarkdown(
        renderableMarkdown,
        md4cFlags,
        isGFM,
        job.textLinkRegex,
        job.codeLinkRegex,
        job.slotIds,
        job.annotateImages,
      ) ?: return emptyList<RenderedSegment>() to false

    val segments = splitASTIntoSegments(ast)
    val renderedSegments =
      MarkdownSegmentRenderer.render(
        segments,
        job.style,
        context,
        onLinkPressCallback,
        onLinkLongPressCallback,
        onLatexError = latexErrorReporter,
      )
    return renderedSegments to hasPendingCodeBlock
  }

  private fun scheduleRender() {
    if (isDisposed) return
    val job = renderJob() ?: return
    val renderId = ++currentRenderId
    executor.execute {
      val (segments, pendingCodeBlock) =
        try {
          runRenderJob(job)
        } catch (e: Exception) {
          Log.e(TAG, "Render failed", e)
          emptyList<RenderedSegment>() to false
        }
      postToMain(renderId) { applyRenderedSegments(segments, pendingCodeBlock) }
    }
  }

  // A slot id change arrives with the commit that mounts the React child, so the
  // placeholder that reserves its space must land in the same frame: render inline
  // instead of one executor hop later, and drop any render already in flight.
  private fun renderSynchronously() {
    if (isDisposed) return
    val job = renderJob() ?: return
    currentRenderId++
    val (segments, pendingCodeBlock) =
      try {
        runRenderJob(job)
      } catch (e: Exception) {
        Log.e(TAG, "Render failed", e)
        emptyList<RenderedSegment>() to false
      }
    applyRenderedSegments(segments, pendingCodeBlock)
  }

  // Trailing code block whose closing fence hasn't streamed in yet, if any.
  private var pendingCodeBlockSegment: RenderedSegment.CodeBlock? = null

  private fun applyRenderedSegments(
    renderedSegments: List<RenderedSegment>,
    hasPendingCodeBlock: Boolean,
  ) {
    pendingCodeBlockSegment =
      if (hasPendingCodeBlock) renderedSegments.lastOrNull() as? RenderedSegment.CodeBlock else null

    val reset = DirtyFlag.RECREATE_SEGMENTS in dirtyFlags
    val forceHeight = DirtyFlag.FORCE_HEIGHT in dirtyFlags
    val remeasure = DirtyFlag.REMEASURE in dirtyFlags
    dirtyFlags.clear()

    val topologyChanged = applySegments(renderedSegments, reset)
    updateBlockSlotHeights(blockSlotHeights)

    // A just-closed block has unchanged content, so the reconciler reuses it
    // without an update; sync pending here to trigger its deferred highlight.
    segmentViews.forEachIndexed { index, view ->
      if (view is CodeBlockContainerView) {
        view.pending = pendingCodeBlockSegment != null && index == segmentViews.size - 1
      }
    }
    codeBlockWrapState.sync()

    if (width > 0) {
      val heightBefore = computeSegmentsTotalHeight()
      layoutSegments()
      val heightAfter = computeSegmentsTotalHeight()

      if (forceHeight || topologyChanged || heightBefore != heightAfter) {
        MeasurementStore.invalidate(id)
        requestLayout()
        stateWrapper?.let {
          val state = Arguments.createMap()
          state.putInt("forceHeightRecalculationCounter", ++forceHeightRecalculationCounter)
          it.updateState(state)
        }
      }
    }
    if (remeasure) onImageLayoutChanged()
  }

  private fun isMathContainerView(view: View): Boolean = mathContainerClass?.isInstance(view) == true

  private fun isVideoContainerView(view: View): Boolean = videoContainerClass?.isInstance(view) == true

  private fun segmentViewConfig(): SegmentViewConfig =
    SegmentViewConfig(
      context = context,
      style = markdownStyle!!,
      allowFontScaling = allowFontScaling,
      maxFontSizeMultiplier = maxFontSizeMultiplier,
      accessibilityLabels = accessibilityLabels,
      selectionMenuConfig = selectionMenuConfig,
      textBreakStrategy = textBreakStrategy,
      selectable = selectable,
      selectionColor = selectionColor,
      selectionHandleColor = selectionHandleColor,
      contextMenuItemTexts = contextMenuItemTexts,
      dynamicProps = dynamicProps,
      onLinkPress = onLinkPressCallback,
      onLinkLongPress = onLinkLongPressCallback,
      onTaskListItemPress = onTaskListItemPressCallback,
      onContextMenuItemPress = ::forwardContextMenuItemPress,
      onLatexError = latexErrorReporter,
    )

  /**
   * Root factory: builds child views through the shared creators, then layers on
   * root-only concerns (spoiler overlay mode, task-list toggle, streaming tail /
   * fade-in animation, and the pending code block sync for the open trailing
   * fence).
   */
  private inner class RootFactory : SegmentViewFactory {
    override fun matchesKind(
      view: View,
      segment: RenderedSegment,
    ): Boolean =
      when (segment) {
        is RenderedSegment.Text -> view is EnrichedMarkdownInternalText
        is RenderedSegment.Table -> view is TableContainerView
        is RenderedSegment.Math -> isMathContainerView(view)
        is RenderedSegment.CodeBlock -> view is CodeBlockContainerView
        is RenderedSegment.Blockquote -> view is BlockquoteContainerView
        is RenderedSegment.Video -> isVideoContainerView(view)
        is RenderedSegment.BlockSlot -> view is BlockSlotSegmentView
      }

    override fun createView(segment: RenderedSegment): View {
      val config = segmentViewConfig()
      return when (segment) {
        is RenderedSegment.Text -> {
          SegmentViewCreators.createTextView(segment, config).apply {
            spoilerOverlay = this@EnrichedMarkdown.spoilerOverlay
            enableTaskListItemToggle = this@EnrichedMarkdown.enableTaskListItemToggle
          }
        }

        is RenderedSegment.Table -> {
          SegmentViewCreators.createTableView(segment, config)
        }

        is RenderedSegment.Math -> {
          SegmentViewCreators.createMathView(segment, config)
        }

        is RenderedSegment.CodeBlock -> {
          SegmentViewCreators.createCodeBlockView(segment, config).apply {
            pending = segment === pendingCodeBlockSegment
          }
        }

        is RenderedSegment.Blockquote -> {
          SegmentViewCreators.createBlockquoteView(segment, config)
        }

        is RenderedSegment.Video -> {
          SegmentViewCreators.createVideoView(segment, config)
        }

        is RenderedSegment.BlockSlot -> {
          SegmentViewCreators.createBlockSlotView(segment, config).apply {
            slotHeight = blockSlotHeights[segment.slotId] ?: 0
          }
        }
      }
    }

    override fun updateView(
      view: View,
      segment: RenderedSegment,
    ) {
      when (segment) {
        is RenderedSegment.Text -> {
          val textView = view as EnrichedMarkdownInternalText
          val tailStart = textView.text?.length ?: 0
          SegmentViewCreators.updateTextView(textView, segment)
          animateTextViewTail(textView, tailStart)
        }

        is RenderedSegment.Table -> {
          val tableView = view as TableContainerView
          val previousRowCount = tableView.rowCount
          tableView.applyTableNode(segment.node)
          if (streamingAnimation && !isReducedMotionEnabled(context)) {
            tableView.animateNewRows(previousRowCount, BLOCK_FADE_DURATION_MS)
          }
        }

        is RenderedSegment.Math -> {
          SegmentViewCreators.updateMathView(view, segment)
        }

        is RenderedSegment.CodeBlock -> {
          (view as CodeBlockContainerView).apply {
            pending = segment === pendingCodeBlockSegment
            applyCodeBlockNode(segment.node)
          }
        }

        is RenderedSegment.Blockquote -> {
          (view as BlockquoteContainerView).applyBlockquoteNode(segment.node, segment.taskIndexOffset)
        }

        is RenderedSegment.Video -> {
          SegmentViewCreators.updateVideoView(view, segment)
        }

        is RenderedSegment.BlockSlot -> {
          SegmentViewCreators.updateBlockSlotView(view as BlockSlotSegmentView, segment)
        }
      }
    }

    override fun animateNewView(
      view: View,
      segment: RenderedSegment,
    ) {
      if (!streamingAnimation) return
      when (segment) {
        is RenderedSegment.Text -> animateTextViewTail(view as EnrichedMarkdownInternalText, 0)

        is RenderedSegment.Table,
        is RenderedSegment.Math,
        is RenderedSegment.CodeBlock,
        is RenderedSegment.Blockquote,
        is RenderedSegment.Video,
        -> animateBlockViewFadeIn(view)

        // The placeholder draws nothing; it grows in once its height arrives.
        is RenderedSegment.BlockSlot -> Unit
      }
    }
  }

  private fun animateTextViewTail(
    view: EnrichedMarkdownInternalText,
    tailStart: Int,
  ) {
    if (!streamingAnimation) return
    val textLength = view.text?.length ?: 0
    if (textLength <= tailStart) return
    TailFadeInAnimator(view).animate(tailStart, textLength)
  }

  private fun animateBlockViewFadeIn(view: View) {
    if (!streamingAnimation) return
    if (isReducedMotionEnabled(context)) return
    view.alpha = 0f
    view
      .animate()
      .alpha(1f)
      .setDuration(BLOCK_FADE_DURATION_MS)
      .start()
  }

  private fun postToMain(
    renderId: Long,
    action: () -> Unit,
  ) {
    mainHandler.post {
      if (!isDisposed && renderId == currentRenderId) action()
    }
  }

  override fun onLayout(
    changed: Boolean,
    l: Int,
    t: Int,
    r: Int,
    b: Int,
  ) {
    layoutSegments()
    slotLayer.layout(0, 0, width, height)
  }

  /** A root slot getting its first height while streaming grows into place ([BlockSlotRevealController]). */
  private fun updateBlockSlotHeights(heights: Map<String, Int>): Boolean {
    val changed = applyBlockSlotHeights(heights)
    blockSlotReveal.noteHeights(heights, segmentViews, streamingAnimation && !isReducedMotionEnabled(context))
    applyBlockSlotReveal()
    return changed
  }

  private fun applyBlockSlotReveal() {
    val targets = (0 until slotLayer.childCount).mapNotNull { slotLayer.getChildAt(it) as? BlockSlotRevealTarget }
    blockSlotReveal.apply(segmentViews, targets)
  }

  private fun stepBlockSlotReveal() {
    applyBlockSlotReveal()
    if (width > 0) layoutSegments()
  }

  fun onImageLayoutChanged() {
    if (isDisposed) return
    if (width > 0) {
      layoutSegments()
      requestLayout()
    }
    MeasurementStore.invalidate(id)
    val wrapper = stateWrapper ?: return
    val state = Arguments.createMap()
    state.putInt("forceHeightRecalculationCounter", ++forceHeightRecalculationCounter)
    wrapper.updateState(state)
  }

  // Shutting the executor down does not cancel results it already posted, nor a
  // render that ignores the interrupt and posts afterwards, so drop those here
  // and refuse further work instead of applying it to a view React has dropped.
  fun cleanup() {
    isDisposed = true
    currentRenderId++
    blockSlotReveal.reset()
    executor.shutdownNow()
    mainHandler.removeCallbacksAndMessages(null)
    stateWrapper = null
  }

  companion object {
    private const val TAG = "EnrichedMarkdown"
    private const val BLOCK_FADE_DURATION_MS = 200L
  }
}
