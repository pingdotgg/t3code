package com.swmansion.rnscreens.core.modals.sheet.coordinator

import android.view.ViewGroup
import android.widget.FrameLayout
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.swmansion.rnscreens.core.modals.sheet.dialog.SheetAvailableHeightProvider
import com.swmansion.rnscreens.core.modals.sheet.dialog.SheetContainer
import com.swmansion.rnscreens.core.modals.sheet.dialog.SheetDialog
import com.swmansion.rnscreens.core.modals.sheet.interfaces.SheetContentSizeChangeDelegate
import com.swmansion.rnscreens.core.modals.sheet.model.SheetDetents

internal class SheetDimensionsCoordinator(
    private val dialog: SheetDialog,
    private val container: SheetContainer,
    private val behaviorController: SheetBehaviorController?,
) : SheetContentSizeChangeDelegate,
    SheetAvailableHeightProvider.OnAvailableHeightMeasuredListener {
    private var lastTopInset = 0
    private var lastBottomInset = 0
    private var lastImeInset = 0
    private var currentDetents: SheetDetents? = null
    private var currentInitialDetentIndex: Int = 0
    private var shouldApplyInitialDetent: Boolean = false

    private var currentContentHeight: Int = 0

    // Height the metrics were last resolved against. Any other value reported by the measure pass
    // means the window has been resized and metrics have to be recomputed.
    private var resolvedAvailableSpace: Int = 0
    private var isGeometryDirty: Boolean = false

    internal fun setup() {
        dialog.availableHeightProvider.availableHeightListener = this
        setupWindowInsetsListener()
    }

    private fun setupWindowInsetsListener() {
        ViewCompat.setOnApplyWindowInsetsListener(container) { _, insets ->
            val topInset = getTopInset(insets)
            val bottomInset = getBottomInset(insets)
            val imeInset = getImeInset(insets)
            if (topInset != lastTopInset || bottomInset != lastBottomInset || imeInset != lastImeInset) {
                lastTopInset = topInset
                lastBottomInset = bottomInset
                lastImeInset = imeInset
                invalidateGeometry()
            }
            insets
        }
    }

    override fun onContentHeightChanged(newHeight: Int) {
        if (currentContentHeight != newHeight) {
            currentContentHeight = newHeight
            invalidateGeometry()
        }
    }

    internal fun updateSheetDimensions(
        detents: SheetDetents?,
        initialDetentIndex: Int = 0,
        applyInitialDetent: Boolean = false,
    ) {
        currentDetents = detents
        currentInitialDetentIndex = initialDetentIndex
        shouldApplyInitialDetent = applyInitialDetent
        invalidateGeometry()
    }

    internal fun onGrabberVisibilityChanged() {
        invalidateGeometry()
    }

    // Schedules a measure pass; the metrics are resolved from there. The provider is a sibling of the sheet
    // subtree, not an ancestor, so it has to be asked for a re-measure explicitly. No-op while the dialog
    // is not shown - the first traversal after `show()` measures everything anyway.
    private fun invalidateGeometry() {
        isGeometryDirty = true
        dialog.availableHeightProvider.requestLayout()
        container.requestLayout()
    }

    override fun onAvailableHeightMeasured(height: Int) {
        if (!isGeometryDirty && height == resolvedAvailableSpace) {
            return
        }
        isGeometryDirty = false
        resolvedAvailableSpace = height
        resolveGeometry(height)
    }

    /**
     * For Yoga we require the container height to be "stable" to avoid updating content size in flight.
     * If left as MATCH_PARENT, BottomSheetDialog dynamically applies insets as padding when sheet overflows
     * status bar or display cutout. This causes Yoga to recalculate the layout, resulting in UI flickering
     * during the drag gesture. By calculating and enforcing a static height that explicitly subtracts
     * the system insets, we completely bypass these redundant layout passes.
     *
     * Runs inside the measure pass of `SheetAvailableHeightProvider`, i.e. before Material's container, the sheet and
     * our container are measured, so the values applied here are picked up by the very same traversal.
     */
    private fun resolveGeometry(sheetAvailableSpace: Int) {
        // The grabber sits above the React content in the container, so the container has to fit both.
        // A non-positive content height means "not measured yet" and is passed through as is.
        val fitToContentsHeight =
            if (currentContentHeight > 0) currentContentHeight + container.measureGrabberHeight() else currentContentHeight

        currentDetents?.let { detents ->
            behaviorController?.updateSheetBehavior(
                detents = detents,
                sheetAvailableSpace = sheetAvailableSpace,
                contentHeightForFitToContents = fitToContentsHeight,
                nativeContainerPaddingBottom = lastBottomInset,
                keyboardLift = keyboardLift,
                initialDetentIndex = currentInitialDetentIndex,
                applyInitialDetent = shouldApplyInitialDetent,
            )
            shouldApplyInitialDetent = false
        }

        val sheetContainerHeight =
            currentDetents?.sheetContainerHeight(
                sheetAvailableSpace,
                lastTopInset,
                lastBottomInset,
                fitToContentsHeight,
                keyboardLift,
            ) ?: (sheetAvailableSpace - lastTopInset - lastBottomInset - keyboardLift).coerceAtLeast(0)

        val layoutParams =
            container.layoutParams
                ?: FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, sheetContainerHeight)

        if (layoutParams.width != ViewGroup.LayoutParams.MATCH_PARENT || layoutParams.height != sheetContainerHeight) {
            layoutParams.width = ViewGroup.LayoutParams.MATCH_PARENT
            layoutParams.height = sheetContainerHeight
            container.layoutParams = layoutParams
        }
    }

    /**
     * The part of the keyboard inset that sticks out above the bottom system inset. Material pads the sheet by
     * the larger of the two, so this is exactly how much the sheet has to be extended to keep its detent-sized
     * part above the keyboard.
     */
    private val keyboardLift: Int
        get() = (lastImeInset - lastBottomInset).coerceAtLeast(0)

    private fun getImeInset(insetsCompat: WindowInsetsCompat): Int = insetsCompat.getInsets(WindowInsetsCompat.Type.ime()).bottom

    private fun getTopInset(insetsCompat: WindowInsetsCompat): Int =
        insetsCompat
            .getInsets(
                WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout(),
            ).top

    private fun getBottomInset(insetsCompat: WindowInsetsCompat): Int =
        insetsCompat
            .getInsets(
                WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout(),
            ).bottom

    internal fun destroy() {
        dialog.availableHeightProvider.availableHeightListener = null
        ViewCompat.setOnApplyWindowInsetsListener(container, null)
    }
}
