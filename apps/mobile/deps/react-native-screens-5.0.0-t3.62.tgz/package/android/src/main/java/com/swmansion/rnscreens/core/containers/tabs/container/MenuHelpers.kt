package com.swmansion.rnscreens.core.containers.tabs.container

import android.view.Menu
import android.view.MenuItem
import com.swmansion.rnscreens.core.containers.tabs.item.TabsScreenFragment

internal fun Menu.getOrCreateMenuItemForFragment(fragment: TabsScreenFragment): MenuItem =
    this.findItem(fragment.menuItemId) ?: this.add(
        Menu.NONE,
        fragment.menuItemId,
        Menu.NONE,
        fragment.item.tabTitle,
    )
