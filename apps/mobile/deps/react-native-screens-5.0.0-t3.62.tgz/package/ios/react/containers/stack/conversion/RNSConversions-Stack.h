#pragma once

#if defined(__cplusplus)

#import <react/renderer/components/rnscreens/Props.h>
#import "RNSDefines.h"
#import "RNSHeaderItemAxisBehavior.h"
#import "RNSHeaderItemPlacement.h"
#import "RNSHeaderItemSpacerPlacement.h"
#import "RNSHeaderItemVisibilityPriority.h"
#import "RNSStackScreenComponentView.h"

namespace rnscreens::conversion {

namespace react = facebook::react;

RNSStackScreenActivityMode
RNSStackScreenActivityModeFromReactRNSStackScreenActivityMode(
    react::RNSStackScreenActivityMode mode);

RNSHeaderItemPlacement
RNSHeaderItemPlacementFromReactRNSStackHeaderItemIOSPlacement(
    react::RNSStackHeaderItemIOSPlacement placement);

RNSHeaderItemSpacerPlacement
RNSHeaderItemSpacerPlacementFromReactRNSStackHeaderItemSpacerIOSPlacement(
    react::RNSStackHeaderItemSpacerIOSPlacement placement);

UIBarButtonItemStyle UIBarButtonItemStyleFromReactRNSStackHeaderItemIOSVariant(
    react::RNSStackHeaderItemIOSVariant variant);

UINavigationItemBackButtonDisplayMode
UINavigationItemBackButtonDisplayModeFromReactRNSStackHeaderConfigIOSBackButtonDisplayMode(
    react::RNSStackHeaderConfigIOSBackButtonDisplayMode displayMode);

#if !TARGET_OS_TV
UINavigationItemStyle
UINavigationItemStyleFromReactRNSStackHeaderConfigIOSNavigationItemStyle(
    react::RNSStackHeaderConfigIOSNavigationItemStyle style)
    API_AVAILABLE(ios(16.0));
#endif // !TARGET_OS_TV

#if RNS_IPHONE_OS_VERSION_AVAILABLE(27_0) && !TARGET_OS_VISION && !TARGET_OS_TV

API_AVAILABLE(ios(27.0))
UIBarMinimizationBehavior
UIBarMinimizationBehaviorFromReactRNSStackHeaderConfigIOSMinimizationBehavior(
    react::RNSStackHeaderConfigIOSMinimizationBehavior minimizationBehavior);

API_AVAILABLE(ios(27.0))
UIBarMinimizationRestorationBehavior
UIBarMinimizationRestorationBehaviorFromReactRNSStackHeaderConfigIOSRestorationBehavior(
    react::RNSStackHeaderConfigIOSRestorationBehavior restorationBehavior);

API_AVAILABLE(ios(27.0))
UIBarMinimizationSafeAreaAdjustment
UIBarMinimizationSafeAreaAdjustmentFromReactRNSStackHeaderConfigIOSSafeAreaAdjustment(
    react::RNSStackHeaderConfigIOSSafeAreaAdjustment safeAreaAdjustment);

#endif // Check for iOS >= 27 && !TARGET_OS_VISION && !TARGET_OS_TV

RNSHeaderItemVisibilityPriority
RNSHeaderItemVisibilityPriorityFromReactRNSStackHeaderItemIOSVisibilityPriority(
    react::RNSStackHeaderItemIOSVisibilityPriority visibilityPriority);

RNSHeaderItemAxisBehavior
RNSHeaderItemAxisBehaviorFromReactRNSStackHeaderItemIOSAxisBehavior(
    react::RNSStackHeaderItemIOSAxisBehavior axisBehavior);

}; // namespace rnscreens::conversion

#endif // defined(__cplusplus)
