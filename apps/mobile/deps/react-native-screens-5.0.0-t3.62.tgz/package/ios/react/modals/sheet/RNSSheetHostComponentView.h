#pragma once

#import "RNSReactBaseView.h"

NS_ASSUME_NONNULL_BEGIN

@interface RNSSheetHostComponentView : RNSReactBaseView

@end

#pragma mark - Props

@interface RNSSheetHostComponentView ()

- (NSArray<NSNumber *> *)detents;

@property (nonatomic, readonly) BOOL isOpen;
@property (nonatomic, readonly) BOOL prefersGrabberVisible;
@property (nonatomic, readonly) BOOL prefersHorizontalBars;
@property (nonatomic, readonly) CGFloat preferredCornerRadius;
@property (nonatomic, readonly) NSInteger largestUndimmedDetentIndex;
@property (nonatomic, readonly) NSInteger initialDetentIndex;
@property (nonatomic, readonly) BOOL prefersScrollingExpandsWhenScrolledToEdge;
@property (nonatomic, readonly) BOOL preventNativeDismiss;
@property (nonatomic, readonly, nullable) UIColor *nativeContainerBackgroundColor;
@property (nonatomic, readonly, nullable) UIVisualEffect *backgroundEffect;

@end

NS_ASSUME_NONNULL_END
