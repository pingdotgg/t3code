#pragma once

#import <UIKit/UIKit.h>
#if defined(__cplusplus)
#import <react/renderer/components/rnscreens/Props.h>
#endif // __cplusplus
#import "RNSDefines.h"
#import "RNSLegacyEnums.h"

#if defined(__cplusplus)
namespace react = facebook::react;
#endif // __cplusplus

@interface RNSConvert : NSObject

#if defined(__cplusplus)

+ (UISemanticContentAttribute)UISemanticContentAttributeFromCppEquivalent:
    (react::RNSScreenStackHeaderConfigDirection)direction;

+ (UINavigationItemBackButtonDisplayMode)UINavigationItemBackButtonDisplayModeFromCppEquivalent:
    (react::RNSScreenStackHeaderConfigBackButtonDisplayMode)backButtonDisplayMode;

+ (RNSOptionalBoolean)RNSOptionalBooleanFromRNSFullScreenSwipeEnabledCppEquivalent:
    (react::RNSScreenFullScreenSwipeEnabled)fullScreenSwipeEnabled;

+ (RNSScreenStackPresentation)RNSScreenStackPresentationFromCppEquivalent:
    (react::RNSScreenStackPresentation)stackPresentation;

+ (RNSScreenStackAnimation)RNSScreenStackAnimationFromCppEquivalent:(react::RNSScreenStackAnimation)stackAnimation;

+ (RNSScreenStackHeaderSubviewType)RNSScreenStackHeaderSubviewTypeFromCppEquivalent:
    (react::RNSScreenStackHeaderSubviewType)subviewType;

#if RNS_IPHONE_OS_VERSION_AVAILABLE(27_0)
+ (UIBarButtonItemVisibilityPriority)UIBarButtonItemVisibilityPriorityFromCppEquivalent:
    (react::RNSScreenStackHeaderSubviewVisibilityPriority)visibilityPriority API_AVAILABLE(ios(27.0));
#endif // RNS_IPHONE_OS_VERSION_AVAILABLE(27_0)

+ (RNSScreenReplaceAnimation)RNSScreenReplaceAnimationFromCppEquivalent:
    (react::RNSScreenReplaceAnimation)replaceAnimation;

+ (RNSScreenSwipeDirection)RNSScreenSwipeDirectionFromCppEquivalent:(react::RNSScreenSwipeDirection)swipeDirection;

+ (RNSScreenSheetBackgroundEffect)RNSScreenSheetBackgroundEffectFromCppEquivalent:
    (react::RNSScreenSheetBackgroundEffect)sheetBackgroundEffect;

+ (NSArray<NSNumber *> *)detentFractionsArrayFromVector:(const std::vector<react::Float> &)detents;

+ (NSDictionary *)gestureResponseDistanceDictFromCppStruct:
    (const react::RNSScreenGestureResponseDistanceStruct &)gestureResponseDistance;

#if !TARGET_OS_VISION
+ (UITextAutocapitalizationType)UITextAutocapitalizationTypeFromCppEquivalent:
    (react::RNSSearchBarAutoCapitalize)autoCapitalize;
#endif

+ (RNSSearchBarPlacement)RNSScreenSearchBarPlacementFromCppEquivalent:(react::RNSSearchBarPlacement)placement;

+ (RNSOptionalBoolean)RNSOptionalBooleanFromRNSSearchBarObscureBackground:
    (react::RNSSearchBarObscureBackground)obscureBackground;

+ (RNSOptionalBoolean)RNSOptionalBooleanFromRNSSearchBarHideNavigationBar:
    (react::RNSSearchBarHideNavigationBar)hideNavigationBar;

+ (UIUserInterfaceStyle)UIUserInterfaceStyleFromCppEquivalent:
    (react::RNSScreenStackHeaderConfigUserInterfaceStyle)userInterfaceStyle;

+ (RNSHeaderMinimizationBehavior)RNSHeaderMinimizationBehaviorFromCppEquivalent:
    (react::RNSScreenStackHeaderConfigMinimizationBehavior)minimizationBehavior;

#if RNS_IPHONE_OS_VERSION_AVAILABLE(27_0) && !TARGET_OS_VISION && !TARGET_OS_TV
/// Converts a resolved (non-`Undefined`) `RNSHeaderMinimizationBehavior` to its UIKit counterpart.
+ (UIBarMinimizationBehavior)UIBarMinimizationBehaviorFromRNSHeaderMinimizationBehavior:
    (RNSHeaderMinimizationBehavior)minimizationBehavior API_AVAILABLE(ios(27.0));

+ (UIBarMinimizationRestorationBehavior)UIBarMinimizationRestorationBehaviorFromCppEquivalent:
    (react::RNSScreenStackHeaderConfigRestorationBehavior)restorationBehavior API_AVAILABLE(ios(27.0));

+ (UIBarMinimizationSafeAreaAdjustment)UIBarMinimizationSafeAreaAdjustmentFromCppEquivalent:
    (react::RNSScreenStackHeaderConfigSafeAreaAdjustment)safeAreaAdjustment API_AVAILABLE(ios(27.0));
#endif // Check for iOS >= 27 && !TARGET_OS_VISION && !TARGET_OS_TV

+ (NSMutableArray<NSNumber *> *)arrayFromVector:(const std::vector<CGFloat> &)vector;

+ (RNSBlurEffectStyle)RNSBlurEffectStyleFromCppEquivalent:(react::RNSScreenStackHeaderConfigBlurEffect)blurEffect;

+ (RNSScrollEdgeEffect)RNSScrollEdgeEffectFromScreenBottomScrollEdgeEffectCppEquivalent:
    (react::RNSScreenBottomScrollEdgeEffect)edgeEffect;
+ (RNSScrollEdgeEffect)RNSScrollEdgeEffectFromScreenLeftScrollEdgeEffectCppEquivalent:
    (react::RNSScreenLeftScrollEdgeEffect)edgeEffect;
+ (RNSScrollEdgeEffect)RNSScrollEdgeEffectFromScreenRightScrollEdgeEffectCppEquivalent:
    (react::RNSScreenRightScrollEdgeEffect)edgeEffect;
+ (RNSScrollEdgeEffect)RNSScrollEdgeEffectFromScreenTopScrollEdgeEffectCppEquivalent:
    (react::RNSScreenTopScrollEdgeEffect)edgeEffect;
+ (id)idFromFollyDynamic:(const folly::dynamic &)dyn;

#endif // __cplusplus

/// This method fails (by assertion) when `blurEffect == RNSBlurEffectStyleNone` or `blurEffect ==
/// RNSBlurEffectStyleSystemDefault` which have no counter parts in the UIKit types.
+ (UIBlurEffectStyle)tryConvertRNSBlurEffectStyleToUIBlurEffectStyle:(RNSBlurEffectStyle)blurEffect;

@end
