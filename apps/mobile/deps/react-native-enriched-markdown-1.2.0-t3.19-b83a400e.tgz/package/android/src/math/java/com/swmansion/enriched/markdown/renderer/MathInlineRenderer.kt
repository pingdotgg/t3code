package com.swmansion.enriched.markdown.renderer

import android.content.Context
import android.text.SpannableStringBuilder
import android.text.style.ForegroundColorSpan
import com.swmansion.enriched.markdown.accessibility.AccessibilityLabels
import com.swmansion.enriched.markdown.accessibility.SpokenSpan
import com.swmansion.enriched.markdown.math.mathLabel
import com.swmansion.enriched.markdown.parser.MarkdownASTNode
import com.swmansion.enriched.markdown.spans.MathInlineSpan
import com.swmansion.enriched.markdown.utils.text.span.SPAN_FLAGS_EXCLUSIVE_EXCLUSIVE
import io.ratex.RaTeXEngine
import io.ratex.RaTeXFontLoader

class MathInlineRenderer(
  private val config: RendererConfig,
  private val context: Context,
) : NodeRenderer {
  override fun render(
    node: MarkdownASTNode,
    builder: SpannableStringBuilder,
    onLinkPress: ((String) -> Unit)?,
    onLinkLongPress: ((String) -> Unit)?,
    factory: RendererFactory,
  ) {
    RaTeXFontLoader.ensureLoaded(context)

    val latex = extractLatex(node)
    if (latex.isEmpty()) return

    val color = config.style.inlineMathStyle.color
    val start = builder.length

    // A replacement span is one unbreakable unit, so the visible `$…$` source of a formula RaTeX
    // rejects goes in as text, which wraps with the paragraph.
    val parseError =
      try {
        RaTeXEngine.parseBlocking(latex, displayMode = false, color = color)
        null
      } catch (e: Exception) {
        e
      }
    if (parseError != null) {
      config.onLatexError?.report(latex, parseError.message, false)
      builder.append("\$").append(latex).append("\$")
      builder.setSpan(MathFallbackSpan(latex, color), start, builder.length, SPAN_FLAGS_EXCLUSIVE_EXCLUSIVE)
      return
    }

    val fontSize =
      factory.blockStyleContext.currentBlockStyleOrNull()?.fontSize
        ?: config.style.mathStyle.fontSize

    builder.append("\uFFFC")
    val end = builder.length

    val span =
      MathInlineSpan(
        context = context,
        latex = latex,
        fontSize = fontSize,
        textColor = color,
        onLatexError = config.onLatexError,
      )

    builder.setSpan(span, start, end, SPAN_FLAGS_EXCLUSIVE_EXCLUSIVE)
  }

  private fun extractLatex(node: MarkdownASTNode): String {
    if (node.content.isNotEmpty()) return node.content
    return node.children.joinToString("") { child ->
      when (child.type) {
        MarkdownASTNode.NodeType.SoftBreak, MarkdownASTNode.NodeType.LineBreak -> " "
        else -> child.content
      }
    }
  }
}

private class MathFallbackSpan(
  private val latex: String,
  color: Int,
) : ForegroundColorSpan(color),
  SpokenSpan {
  override fun accessibilityLabel(labels: AccessibilityLabels): String = labels.mathLabel(latex)
}
