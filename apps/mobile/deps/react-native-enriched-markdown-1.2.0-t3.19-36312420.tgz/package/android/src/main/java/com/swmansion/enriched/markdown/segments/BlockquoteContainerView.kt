package com.swmansion.enriched.markdown.segments

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import android.text.TextDirectionHeuristics
import android.text.TextPaint
import android.text.TextUtils
import android.view.View
import androidx.core.graphics.withSave
import com.facebook.react.common.ReactConstants
import com.facebook.react.views.text.ReactTypefaceUtils.applyStyles
import com.swmansion.enriched.markdown.CodeBlockWrapCursor
import com.swmansion.enriched.markdown.EnrichedMarkdownInternalText
import com.swmansion.enriched.markdown.parser.MarkdownASTNode
import com.swmansion.enriched.markdown.styles.BlockquoteStyle
import com.swmansion.enriched.markdown.styles.StyleConfig
import com.swmansion.enriched.markdown.utils.common.BreakStrategyUtils
import com.swmansion.enriched.markdown.utils.common.layout.isLayoutRTL
import com.swmansion.enriched.markdown.utils.common.serialization.MarkdownASTSerializer
import com.swmansion.enriched.markdown.views.ContextMenuPopup
import kotlin.math.ceil
import kotlin.math.max
import kotlin.math.roundToInt

/**
 * A GFM blockquote rendered as a recursive container: it splits its own AST
 * children into segments and lays them out through the shared ContainerNodeView
 * machinery, so a nested quote becomes another BlockquoteContainerView, a fenced
 * code block becomes a CodeBlockContainerView, and prose collapses into a single
 * text view. Nesting depth is automatic: each level is its own view, inset
 * further by its padding, so onDraw only ever renders one accent bar plus the
 * background for this single level.
 *
 * The content inset is applied as this view's padding (the bar's edge =
 * borderWidth + gapWidth + padding, other edges = padding; the bar is on the
 * right in a right-to-left quote), mirroring the geometry
 * BlockquoteSpan draws for the in-text (list-nested) path; the base measure and
 * layout already honor padding.
 *
 * Streaming is treated as static inside a quote (no pending-fence handling, no
 * tail/fade animation) to keep the recursion tractable; a content change re-signs
 * the whole container so the reconciler still reuses the outer quote view.
 */
class BlockquoteContainerView(
  context: Context,
  private val parentConfig: SegmentViewConfig,
) : ContainerNodeView(context),
  BlockSegmentView {
  private val blockquoteStyle: BlockquoteStyle = parentConfig.style.blockquoteStyle

  private val borderWidthPx: Float = blockquoteStyle.borderWidth
  private val paddingPx: Float = blockquoteStyle.padding
  private val leadingInset: Int = ceil(borderWidthPx + blockquoteStyle.gapWidth + paddingPx).toInt()
  private val verticalInset: Int = ceil(paddingPx).toInt()
  private val trailingInset: Int = ceil(paddingPx).toInt()

  private var rightToLeft = false

  var outerRightToLeft: Boolean? = null
    set(value) {
      if (field == value) return
      field = value
      if (value != null) applySide(value)
    }

  // Set from the applied node: null for a plain quote, the admonition type
  // ("note"/"tip"/…) otherwise. Drives the header + per-type theming.
  private var admonitionType: String? = null

  // Cached markdown source for the "Copy as Markdown" action.
  private var cachedMarkdown: String = ""

  // Cached plain text for the "Copy" action.
  private var cachedPlainText: String = ""

  private val iconSizePx: Int = ceil(blockquoteStyle.fontSize).toInt()

  private val titlePaint =
    TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
      typeface =
        Typeface.create(
          applyStyles(
            null,
            ReactConstants.UNSET,
            ReactConstants.UNSET,
            blockquoteStyle.fontFamily.takeIf { it.isNotEmpty() },
            context.assets,
          ),
          Typeface.BOLD,
        )
      textSize = blockquoteStyle.fontSize
    }
  private val iconPaint =
    Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }

  private fun reservedHeaderHeight(): Int = if (admonitionType != null) ceil(admonitionHeaderReservedHeight(blockquoteStyle)).toInt() else 0

  // Only the outermost quote carries vertical margins; a quote nested directly
  // inside another quote is separated by the parent's padding alone (matches the
  // commonmark BlockquoteRenderer, which applies margins only at depth 0).
  var nested: Boolean = false

  override val segmentMarginTop: Int get() = if (nested) 0 else blockquoteStyle.marginTop.toInt()
  override val segmentMarginBottom: Int get() = if (nested) 0 else blockquoteStyle.marginBottom.toInt()

  private val backgroundPaint =
    Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
  private val borderPaint =
    Paint(Paint.ANTI_ALIAS_FLAG).apply {
      style = Paint.Style.FILL
      color = blockquoteStyle.borderColor
    }
  private val rect = RectF()
  private val path = Path()
  private val radiiArray = FloatArray(8)

  init {
    setWillNotDraw(false)
    applyInsets()
    segmentViewFactory = NestedSegmentViewFactory(parentConfig, withinBlockquote = true)
    trailingMarginEnabled = false
    isLongClickable = true
    setOnLongClickListener { view -> showContextMenu(view) }
  }

  /** [taskIndexOffset] is the document-global index of the quote's first task-list item. */
  fun applyBlockquoteNode(
    node: MarkdownASTNode,
    taskIndexOffset: Int = 0,
    listDepth: Int = 0,
    parentMarkerWidth: Float? = null,
  ) {
    admonitionType =
      if (node.type == MarkdownASTNode.NodeType.Admonition) {
        node.getAttribute("admonitionType")?.takeIf { it.isNotEmpty() } ?: "note"
      } else {
        null
      }
    cachedMarkdown = MarkdownASTSerializer.serializeBlockquote(node)
    cachedPlainText = MarkdownASTSerializer.plainText(node)

    val segments = splitASTIntoSegments(node, listContainer = listDepth > 0)
    val rendered =
      MarkdownSegmentRenderer.render(
        segments,
        parentConfig.style,
        context,
        parentConfig.onLinkPress,
        parentConfig.onLinkLongPress,
        blockquoteStyle,
        onLatexError = parentConfig.onLatexError,
        startingTaskIndex = taskIndexOffset,
        listDepth = listDepth,
        parentMarkerWidth = parentMarkerWidth,
      )
    rightToLeft = outerRightToLeft ?: isRightToLeft(node, resources.isLayoutRTL())
    applyInsets()
    applySegments(rendered, reset = false)
    applySide(rightToLeft)
    requestLayout()
  }

  // Moves the bar, padding and header to one side, and hands the side to nested
  // quotes, which a parent's update can leave untouched.
  private fun applySide(rightToLeft: Boolean) {
    if (this.rightToLeft != rightToLeft) {
      this.rightToLeft = rightToLeft
      applyInsets()
      invalidate()
    }
    segmentViews.forEach {
      when (it) {
        is BlockquoteContainerView -> it.outerRightToLeft = rightToLeft
        is ListContainerView -> it.outerRightToLeft = rightToLeft
      }
    }
  }

  private fun applyInsets() {
    val top = verticalInset + reservedHeaderHeight()
    if (rightToLeft) {
      setPadding(trailingInset, top, leadingInset, verticalInset)
    } else {
      setPadding(leadingInset, top, trailingInset, verticalInset)
    }
  }

  private fun showContextMenu(anchor: View): Boolean {
    if (!parentConfig.dynamicProps.enableBlockContextMenu) return false
    val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
    ContextMenuPopup.show(anchor, this) {
      item(ContextMenuPopup.Icon.COPY, parentConfig.dynamicProps.copyLabel) {
        if (cachedPlainText.isNotEmpty()) {
          clipboard.setPrimaryClip(ClipData.newPlainText("Blockquote", cachedPlainText))
        }
      }
      item(ContextMenuPopup.Icon.DOCUMENT, parentConfig.dynamicProps.copyAsMarkdownLabel) {
        if (cachedMarkdown.isNotEmpty()) {
          clipboard.setPrimaryClip(ClipData.newPlainText("Blockquote", cachedMarkdown))
        }
      }
    }
    return true
  }

  override fun onMeasure(
    widthSpec: Int,
    heightSpec: Int,
  ) {
    val measuredWidth = MeasureSpec.getSize(widthSpec)
    measureSegmentChildren(measuredWidth)
    setMeasuredDimension(measuredWidth, computeSegmentsTotalHeight())
  }

  override fun onLayout(
    changed: Boolean,
    l: Int,
    t: Int,
    r: Int,
    b: Int,
  ) {
    layoutSegments()
  }

  override fun onDraw(canvas: Canvas) {
    super.onDraw(canvas)
    val radius = blockquoteStyle.borderRadius
    val hasRadius = radius > 0f

    // Admonitions theme the box with their per-type color; a plain quote keeps
    // the base blockquote colors.
    val type = admonitionType
    val tint =
      if (type != null) {
        blockquoteStyle.admonitions[type]?.color ?: blockquoteStyle.borderColor
      } else {
        blockquoteStyle.borderColor
      }
    val bgColor =
      if (type != null) {
        blockquoteStyle.admonitions[type]?.backgroundColor?.takeIf { it != Color.TRANSPARENT }
      } else {
        blockquoteStyle.backgroundColor?.takeIf { it != Color.TRANSPARENT }
      }
    borderPaint.color = tint

    if (hasRadius) {
      rect.set(0f, 0f, width.toFloat(), height.toFloat())
      radiiArray.fill(radius)
      path.reset()
      path.addRoundRect(rect, radiiArray, Path.Direction.CW)
    }

    if (bgColor != null) {
      backgroundPaint.color = bgColor
      if (hasRadius) {
        canvas.drawPath(path, backgroundPaint)
      } else {
        canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), backgroundPaint)
      }
    }

    // Clip the accent bar to the rounded box so its outer corners follow the
    // border radius instead of poking past the background as squares.
    val barLeft = if (rightToLeft) width - borderWidthPx else 0f
    if (hasRadius) {
      canvas.withSave {
        clipPath(path)
        drawRect(barLeft, 0f, barLeft + borderWidthPx, height.toFloat(), borderPaint)
      }
    } else {
      canvas.drawRect(barLeft, 0f, barLeft + borderWidthPx, height.toFloat(), borderPaint)
    }

    if (type != null) {
      drawAdmonitionHeader(canvas, type, tint)
    }
  }

  // Draws the admonition header (tinted octicon + title) in the band
  // reserved at the top of the view by the enlarged top padding, on the bar's side.
  private fun drawAdmonitionHeader(
    canvas: Canvas,
    type: String,
    tint: Int,
  ) {
    val headerTop = verticalInset.toFloat()
    val headerHeight = admonitionHeaderContentHeight(blockquoteStyle)
    var titleInset = leadingInset.toFloat()

    val iconPath = AdmonitionIcons.path(type)
    if (iconPath != null) {
      val scale = iconSizePx / AdmonitionIcons.VIEWBOX
      val iconX = if (rightToLeft) width - leadingInset - iconSizePx else leadingInset
      val iconY = headerTop + (headerHeight - iconSizePx) / 2f
      iconPaint.color = tint
      canvas.withSave {
        translate(iconX.toFloat(), iconY)
        scale(scale, scale)
        drawPath(iconPath, iconPaint)
      }
      titleInset = (leadingInset + iconSizePx + (iconSizePx * 0.4f).roundToInt()).toFloat()
    }

    titlePaint.color = tint
    val fm = titlePaint.fontMetrics
    val baseline = headerTop + headerHeight / 2f - (fm.ascent + fm.descent) / 2f
    val title = parentConfig.style.admonitionTitles[type].orEmpty()
    val titleWidth = width - trailingInset - titleInset
    if (title.isEmpty() || titleWidth <= 0f) return
    val fitted = TextUtils.ellipsize(title, titlePaint, titleWidth, TextUtils.TruncateAt.END)
    val titleX = if (rightToLeft) width - titleInset - titlePaint.measureText(fitted, 0, fitted.length) else titleInset
    canvas.drawText(fitted, 0, fitted.length, titleX, baseline, titlePaint)
  }

  companion object {
    // Height of the header band (icon + title row). Shared by the instance draw
    // path and the view-free measurement so both reserve identical space.
    fun admonitionHeaderContentHeight(style: BlockquoteStyle): Float = ceil(max(ceil(style.fontSize), style.fontSize * 1.35f))

    // Vertical space the header adds above the body (band + gap).
    fun admonitionHeaderReservedHeight(style: BlockquoteStyle): Float =
      admonitionHeaderContentHeight(style) + (style.fontSize * 0.4f).roundToInt()

    private val directionlessTypes =
      setOf(
        MarkdownASTNode.NodeType.CodeBlock,
        MarkdownASTNode.NodeType.Image,
        MarkdownASTNode.NodeType.Video,
        MarkdownASTNode.NodeType.LatexMathInline,
        MarkdownASTNode.NodeType.LatexMathDisplay,
      )

    /** The first strong character in the quote; without one, [layoutIsRtl] decides. */
    private fun isRightToLeft(
      node: MarkdownASTNode,
      layoutIsRtl: Boolean,
    ): Boolean = firstStrongIsRtl(node) ?: layoutIsRtl

    /**
     * The first strong character in [node], as web's `dir="auto"` finds it: nested quotes and
     * tables count, code blocks, images and math do not. `null` when there is none.
     */
    private fun firstStrongIsRtl(node: MarkdownASTNode): Boolean? {
      if (node.type in directionlessTypes) return null
      val text = node.content
      if (TextDirectionHeuristics.FIRSTSTRONG_LTR.isRtl(text, 0, text.length)) return true
      if (!TextDirectionHeuristics.FIRSTSTRONG_RTL.isRtl(text, 0, text.length)) return false
      return node.children.firstNotNullOfOrNull { firstStrongIsRtl(it) }
    }

    /**
     * View-free height of a blockquote node at the given outer content width.
     * The children are summed at the reduced inner width (outer minus horizontal
     * inset) and the vertical inset is added; nested quotes recurse through this
     * same function via SegmentHeightMeasurer. Math child heights use the shared
     * estimate to avoid a main-thread measure from the layout pass. Wrapped code
     * blocks (wrapCursor) lay out at the inner width, as the views do.
     *
     * Potential win: this runs splitASTIntoSegments + render for measurement, and
     * applyBlockquoteNode runs them again for display, so each nesting level renders
     * its content twice. The two passes run on different threads (this one off the
     * main thread, view creation on it) and key off different widths, so a shared
     * cache would need to be thread-safe and width-aware; not worth it yet, but the
     * rendered segments could be memoized so the view path reuses this result.
     */
    fun measureBlockquoteNodeHeight(
      node: MarkdownASTNode,
      config: StyleConfig,
      context: Context,
      width: Float,
      wrapCursor: CodeBlockWrapCursor? = null,
      // Slot children inside the quote report absolute origins: the quote's own
      // origin (px, within the host content box) plus its insets.
      slotMeasurer: BlockSlotMeasurer? = null,
      originXPx: Float = 0f,
      originYPx: Float = 0f,
      // The side of the quote around this one, for a nested quote (outerRightToLeft).
      outerRightToLeft: Boolean? = null,
      listDepth: Int = 0,
      parentMarkerWidth: Float? = null,
    ): Float {
      val style = config.blockquoteStyle
      val leadingInset = ceil(style.borderWidth + style.gapWidth + style.padding).toInt()
      val trailingInset = ceil(style.padding).toInt()
      val verticalInset = ceil(style.padding).toInt()
      val headerReserved =
        if (node.type == MarkdownASTNode.NodeType.Admonition) {
          ceil(admonitionHeaderReservedHeight(style))
        } else {
          0f
        }
      // The view lays its children out at integer pixels (measureSegmentChildren
      // receives ceil(width)), so measure at the same rounded width or the two
      // paths wrap long lines differently.
      val innerWidth = (ceil(width) - leadingInset - trailingInset).coerceAtLeast(1f)

      val segments = splitASTIntoSegments(node, listContainer = listDepth > 0)
      val rendered =
        MarkdownSegmentRenderer.render(
          segments,
          config,
          context,
          null,
          null,
          style,
          listDepth = listDepth,
          parentMarkerWidth = parentMarkerWidth,
        )
      val rightToLeft = outerRightToLeft ?: isRightToLeft(node, context.resources.isLayoutRTL())
      val leftInset = if (rightToLeft) trailingInset else leadingInset

      val fontSize = style.fontSize
      val breakStrategy = BreakStrategyUtils.resolveBreakStrategy(null)

      val childrenHeight =
        SegmentHeightMeasurer.measureSegmentsHeight(
          segments = rendered,
          style = config,
          context = context,
          contentWidthPx = innerWidth,
          fontSizePx = fontSize,
          breakStrategy = breakStrategy,
          allowTrailingMargin = false,
          mathHeightForIndex = { estimateMathHeight(config) },
          wrapCursor = wrapCursor,
          slotMeasurer = slotMeasurer,
          originXPx = originXPx + leftInset,
          originYPx = originYPx + verticalInset + headerReserved,
          quoteRightToLeft = rightToLeft,
        )

      return childrenHeight + verticalInset * 2f + headerReserved
    }

    private fun estimateMathHeight(config: StyleConfig): Float {
      val estimatedHeight = config.mathStyle.fontSize * 1.4f
      return estimatedHeight + config.mathStyle.padding * 2
    }
  }
}
