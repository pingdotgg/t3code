# Auggie CLI

Auggie CLI takes the power of Augment's agent and context engine and puts it in your terminal,
allowing you to use Augment anywhere your code goes. You can use Auggie in a standalone interactive
terminal session alongside your favorite editor or in any part of your software development stack.

## Installation

```bash
npm install -g @augmentcode/auggie
```

**Requirements:**
- Node.js 22 or later
- A compatible shell (zsh, bash, fish)

## Quick Start

1. Navigate to your project directory:
   ```bash
   cd /path/to/your/project
   ```

2. Login to your Augment account:
   ```bash
   auggie login
   ```

3. Start using Auggie:
   ```bash
   auggie "Give me a summary of this project"
   ```

## Documentation

For complete documentation, setup guides, and advanced usage, visit:

📖 https://docs.augmentcode.com/cli/overview

## License

See LICENSE.md for license information.
