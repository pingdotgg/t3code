/**
 * Platform detection utilities for @factory/cli
 *
 * Exports the platform package mapping and helper functions for
 * determining the correct binary to use.
 */

const fs = require('fs');
const child_process = require('child_process');

// Platform-specific package mapping
// x64 platforms have both regular (AVX2) and baseline (no AVX2) variants
const PLATFORM_PACKAGES = {
  'darwin-arm64': { regular: '@factory/cli-darwin-arm64' },
  'darwin-x64': {
    regular: '@factory/cli-darwin-x64',
    baseline: '@factory/cli-darwin-x64-baseline',
  },
  'linux-arm64': { regular: '@factory/cli-linux-arm64' },
  'linux-x64': {
    regular: '@factory/cli-linux-x64',
    baseline: '@factory/cli-linux-x64-baseline',
  },
  'win32-x64': {
    regular: '@factory/cli-win32-x64',
    baseline: '@factory/cli-win32-x64-baseline',
  },
  'win32-arm64': { regular: '@factory/cli-win32-arm64' },
};

// All packages (used for optionalDependencies)
const ALL_PACKAGES = Object.values(PLATFORM_PACKAGES).flatMap((p) =>
  [p.regular, p.baseline].filter(Boolean)
);

function getPlatformKey() {
  return `${process.platform}-${process.arch}`;
}

function getBinaryName() {
  return process.platform === 'win32' ? 'droid.exe' : 'droid';
}

function getPlatformPackages() {
  const platformKey = getPlatformKey();
  return PLATFORM_PACKAGES[platformKey] || null;
}

/**
 * Detect if CPU supports AVX2 instructions.
 * Returns true if AVX2 is supported, false if not, null if detection failed.
 */
function detectAVX2Support() {
  try {
    if (process.platform === 'linux') {
      const cpuinfo = fs.readFileSync('/proc/cpuinfo', 'utf8');
      return cpuinfo.toLowerCase().includes('avx2');
    } else if (process.platform === 'darwin') {
      const result = child_process.execSync(
        'sysctl -n machdep.cpu.leaf7_features',
        { encoding: 'utf8', timeout: 5000 }
      );
      return result.toLowerCase().includes('avx2');
    } else if (process.platform === 'win32') {
      // Windows: use kernel32.dll IsProcessorFeaturePresent(40) via PowerShell
      // Feature ID 40 = PF_AVX2_INSTRUCTIONS_AVAILABLE
      // This is the same method used by the Factory CLI installer and Bun
      const script =
        '$ProgressPreference = "SilentlyContinue"; ' +
        'try { ' +
        '$hasAvx2 = (Add-Type -MemberDefinition \'[DllImport("kernel32.dll")] public static extern bool IsProcessorFeaturePresent(int ProcessorFeature);\' -Name "Kernel32" -Namespace "Win32" -PassThru -ErrorAction Stop)::IsProcessorFeaturePresent(40); ' +
        'if ($hasAvx2) { Write-Output "true" } else { Write-Output "false" } ' +
        '} catch { ' +
        'try { ' +
        '$hasAvx2 = ([Win32.Kernel32]::IsProcessorFeaturePresent(40)); ' +
        'if ($hasAvx2) { Write-Output "true" } else { Write-Output "false" } ' +
        '} catch { ' +
        'Write-Output "unknown" ' +
        '} }';
      const encodedScript = Buffer.from(script, 'utf16le').toString('base64');
      const result = child_process.execSync(
        `powershell -NoProfile -NonInteractive -EncodedCommand ${encodedScript}`,
        { encoding: 'utf8', timeout: 10000 }
      );
      const output = result.trim().toLowerCase();
      if (output === 'true') return true;
      if (output === 'false') return false;
      // 'unknown' or other - detection failed
      return null;
    }
  } catch (e) {
    // Detection failed
  }
  return null;
}

function resolveBinaryPath(packageName) {
  if (!packageName) return null;
  try {
    return require.resolve(`${packageName}/bin/${getBinaryName()}`, {
      paths: [__dirname, process.cwd()],
    });
  } catch (e) {
    return null;
  }
}

/**
 * Get the binary path with AVX2-aware package selection.
 * Returns { path, pkg, hasBaseline } or null if not found.
 */
function getBinaryPathWithInfo() {
  const packages = getPlatformPackages();
  if (!packages) {
    return null;
  }

  const hasBaseline = !!packages.baseline;
  let useBaseline = false;

  if (hasBaseline) {
    const avx2Supported = detectAVX2Support();
    if (avx2Supported === false) {
      useBaseline = true;
    }
  }

  const preferredPkg = useBaseline ? packages.baseline : packages.regular;
  const fallbackPkg = useBaseline ? packages.regular : packages.baseline;

  let binPath = resolveBinaryPath(preferredPkg);
  let selectedPkg = preferredPkg;

  if (!binPath && fallbackPkg) {
    binPath = resolveBinaryPath(fallbackPkg);
    selectedPkg = fallbackPkg;
  }

  if (!binPath) {
    return null;
  }

  return { path: binPath, pkg: selectedPkg, hasBaseline };
}

/**
 * Get the binary path (simple version for backward compatibility).
 */
function getBinaryPath() {
  const result = getBinaryPathWithInfo();
  return result ? result.path : null;
}

function isSupportedPlatform() {
  return getPlatformPackages() !== null;
}

module.exports = {
  PLATFORM_PACKAGES,
  ALL_PACKAGES,
  getPlatformKey,
  getBinaryName,
  getPlatformPackages,
  detectAVX2Support,
  resolveBinaryPath,
  getBinaryPathWithInfo,
  getBinaryPath,
  isSupportedPlatform,
};
