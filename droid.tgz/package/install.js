#!/usr/bin/env node

/**
 * postinstall script for @factory/cli
 *
 * This script optimizes the installed package by replacing the JavaScript shim
 * with a hard link to the actual binary executable. This avoids the overhead
 * of launching another Node.js process when using the "droid" command.
 *
 * Based on esbuild's approach: https://github.com/evanw/esbuild/pull/1621
 * and Sentry's guide: https://sentry.engineering/blog/publishing-binaries-on-npm
 *
 * On Unix: replaces bin/droid with hard link to the platform binary
 * On Windows: keeps JS shim (Windows requires .exe extension)
 * With --ignore-scripts: falls back to JS shim (still works, just slower)
 */

const fs = require('fs');
const path = require('path');
const https = require('https');
const zlib = require('zlib');
const child_process = require('child_process');

const {
  PLATFORM_PACKAGES,
  getPlatformKey,
  getBinaryName,
  getBinaryPath,
  detectAVX2Support,
} = require('./platform.js');

// Read version - handle case where package.json doesn't exist yet (template dir)
let PACKAGE_VERSION = '0.0.0';
try {
  PACKAGE_VERSION = require('./package.json').version;
} catch (e) {
  // Running from template directory before build
}

function isYarn2OrAbove() {
  const { npm_config_user_agent } = process.env;
  if (npm_config_user_agent) {
    const match = npm_config_user_agent.match(/yarn\/(\d+)/);
    if (match && match[1]) {
      return parseInt(match[1], 10) >= 2;
    }
  }
  return false;
}

function validateBinaryVersion(binaryPath) {
  try {
    const result = child_process.execFileSync(binaryPath, ['--version'], {
      encoding: 'utf8',
      timeout: 10000,
    });
    const version = result.trim().split('\n')[0];
    // Version format might be "droid 0.50.0" or just "0.50.0"
    if (PACKAGE_VERSION !== '0.0.0' && !version.includes(PACKAGE_VERSION)) {
      console.warn(
        `Warning: Binary version mismatch. Expected ${PACKAGE_VERSION}, got ${version}`
      );
    }
  } catch (e) {
    // Version check is optional, don't fail install
  }
}

/**
 * Make an HTTPS request with optional npm authentication.
 * Uses NPM_TOKEN env var if available to bypass rate limits.
 */
function makeRequest(url) {
  return new Promise((resolve, reject) => {
    const parsedUrl = new URL(url);
    const options = {
      hostname: parsedUrl.hostname,
      path: parsedUrl.pathname + parsedUrl.search,
      headers: {},
    };

    // Add auth header if NPM_TOKEN is available (bypasses rate limits in CI)
    if (process.env.NPM_TOKEN && parsedUrl.hostname.includes('npmjs.org')) {
      options.headers['Authorization'] = `Bearer ${process.env.NPM_TOKEN}`;
    }

    https
      .get(options, (response) => {
        if (response.statusCode >= 200 && response.statusCode < 300) {
          const chunks = [];
          response.on('data', (chunk) => chunks.push(chunk));
          response.on('end', () => resolve(Buffer.concat(chunks)));
        } else if (
          response.statusCode >= 300 &&
          response.statusCode < 400 &&
          response.headers.location
        ) {
          makeRequest(response.headers.location).then(resolve, reject);
        } else {
          reject(
            new Error(
              `npm responded with status code ${response.statusCode} when downloading the package`
            )
          );
        }
      })
      .on('error', reject);
  });
}

/**
 * Fetch the tarball URL from npm registry packument.
 * This is more reliable than constructing the URL manually.
 */
function fetchTarballUrl(packageName, version) {
  return new Promise((resolve, reject) => {
    const encodedName = packageName.replace('/', '%2f');
    const url = `https://registry.npmjs.org/${encodedName}`;

    makeRequest(url)
      .then((buffer) => {
        const packument = JSON.parse(buffer.toString('utf8'));
        const versionData = packument.versions?.[version];
        if (!versionData) {
          throw new Error(
            `Version ${version} not found for package ${packageName}`
          );
        }
        const tarballUrl = versionData.dist?.tarball;
        if (!tarballUrl) {
          throw new Error(`No tarball URL found for ${packageName}@${version}`);
        }
        resolve(tarballUrl);
      })
      .catch(reject);
  });
}

/**
 * Download the platform-specific package from npm registry as a fallback.
 * This handles the case where optionalDependencies were disabled.
 */
function downloadBinaryFromNpm() {
  return new Promise((resolve, reject) => {
    const platformKey = getPlatformKey();
    const packages = PLATFORM_PACKAGES[platformKey];

    if (!packages) {
      reject(new Error(`Unsupported platform: ${platformKey}`));
      return;
    }

    // Choose package based on AVX2 support
    const hasBaseline = !!packages.baseline;
    let useBaseline = false;
    if (hasBaseline) {
      const avx2Supported = detectAVX2Support();
      if (avx2Supported === false) {
        useBaseline = true;
      }
    }

    const packageName = useBaseline ? packages.baseline : packages.regular;

    console.log(`Downloading ${packageName}@${PACKAGE_VERSION} from npm...`);

    // Fetch the tarball URL from packument instead of constructing it manually
    fetchTarballUrl(packageName, PACKAGE_VERSION)
      .then((tarballUrl) => makeRequest(tarballUrl))
      .then((tarballBuffer) => {
        const unzipped = zlib.gunzipSync(tarballBuffer);
        const binaryName = getBinaryName();
        const binaryData = extractFileFromTarball(
          unzipped,
          `package/bin/${binaryName}`
        );

        if (!binaryData) {
          throw new Error(
            `Binary not found in tarball: package/bin/${binaryName}`
          );
        }

        // Ensure bin directory exists before writing
        const binDir = path.join(__dirname, 'bin');
        fs.mkdirSync(binDir, { recursive: true });

        // Write binary to local bin directory
        const localBinPath = path.join(binDir, binaryName);
        fs.writeFileSync(localBinPath, binaryData, { mode: 0o755 });

        console.log(`Downloaded and extracted binary to ${localBinPath}`);
        resolve(localBinPath);
      })
      .catch(reject);
  });
}

function extractFileFromTarball(tarballBuffer, filepath) {
  // Tar archives are organized in 512 byte blocks
  let offset = 0;
  while (offset < tarballBuffer.length) {
    const header = tarballBuffer.subarray(offset, offset + 512);
    offset += 512;

    const fileName = header.toString('utf-8', 0, 100).replace(/\0.*/g, '');
    const fileSize = parseInt(
      header.toString('utf-8', 124, 136).replace(/\0.*/g, ''),
      8
    );

    if (isNaN(fileSize)) break;

    if (fileName === filepath) {
      return tarballBuffer.subarray(offset, offset + fileSize);
    }

    // Clamp offset to the upper multiple of 512
    offset = (offset + fileSize + 511) & ~511;
  }
  return null;
}

/**
 * Check if this is a global npm install by looking at the npm_config_global
 * environment variable that npm sets during installation.
 */
function isGlobalInstall() {
  return (
    process.env.npm_config_global === 'true' ||
    process.env.npm_config_global === ''
  );
}

/**
 * Detect the npm global bin directory.
 * Uses `npm prefix -g` and appends /bin on POSIX (Windows puts binaries
 * directly in the prefix directory).
 */
function getNpmGlobalBinDir() {
  try {
    const prefix = child_process
      .execSync('npm prefix -g', { encoding: 'utf8', timeout: 10000 })
      .trim();
    if (!prefix) return null;
    return process.platform === 'win32' ? prefix : path.join(prefix, 'bin');
  } catch (e) {
    return null;
  }
}

/**
 * Check if a directory is already present in the current PATH.
 * Uses path.resolve() to normalize slashes and handles case-insensitive
 * comparison on Windows.
 */
function isDirInPath(dir) {
  const envPath = process.env.PATH || '';
  const sep = process.platform === 'win32' ? ';' : ':';
  const normalize = (d) => path.resolve(d);
  const normalizedDir = normalize(dir);
  const dirs = envPath.split(sep).map(normalize);
  if (process.platform === 'win32') {
    return dirs.some((d) => d.toLowerCase() === normalizedDir.toLowerCase());
  }
  return dirs.includes(normalizedDir);
}

/**
 * Detect the user's shell and suggest the appropriate profile file.
 */
function getShellProfileHint() {
  const shell = process.env.SHELL || '';
  const shellName = path.basename(shell);
  if (shellName === 'zsh') return '~/.zshrc';
  if (shellName === 'bash') {
    return process.platform === 'darwin' ? '~/.bash_profile' : '~/.bashrc';
  }
  if (shellName === 'fish') return '~/.config/fish/config.fish';
  return null;
}

/**
 * Print a warning if the npm global bin directory is not in the user's PATH.
 * Only runs for global installs. Does NOT modify any files.
 */
function warnIfNotInPath() {
  try {
    if (process.env.CI || process.env.CONTINUOUS_INTEGRATION) return;
    if (!isGlobalInstall()) return;

    const binDir = getNpmGlobalBinDir();
    if (!binDir) return;
    if (isDirInPath(binDir)) return;

    const profileHint = getShellProfileHint();

    if (process.platform === 'win32') {
      console.log(
        '\n' +
          'Note: The "droid" command may not be available in your terminal.\n' +
          `The npm global bin directory is not in your PATH:\n` +
          `  ${binDir}\n\n` +
          'To fix for this session, run:\n' +
          `  set PATH=%PATH%;${binDir}\n\n` +
          'To fix permanently (PowerShell):\n' +
          `  [Environment]::SetEnvironmentVariable('Path', $env:PATH + ';${binDir}', 'User')\n\n` +
          'Then restart your terminal.\n'
      );
    } else if (profileHint) {
      const exportLine =
        profileHint === '~/.config/fish/config.fish'
          ? `fish_add_path "${binDir}"`
          : `export PATH="${binDir}:$PATH"`;

      console.log(
        '\n' +
          'Note: The "droid" command may not be available in your terminal.\n' +
          `The npm global bin directory is not in your PATH:\n` +
          `  ${binDir}\n\n` +
          `To fix, run:\n` +
          `  echo '${exportLine}' >> ${profileHint} && source ${profileHint}\n`
      );
    } else {
      console.log(
        '\n' +
          'Note: The "droid" command may not be available in your terminal.\n' +
          `The npm global bin directory is not in your PATH:\n` +
          `  ${binDir}\n\n` +
          'To fix, add the following to your shell profile (~/.bashrc, ~/.zshrc, etc.):\n' +
          `  export PATH="${binDir}:$PATH"\n\n` +
          'Then restart your terminal.\n'
      );
    }
  } catch (e) {
    // PATH check is best-effort; never fail the install
  }
}

async function main() {
  const shimPath = path.join(__dirname, 'bin', 'droid');
  let binaryPath = getBinaryPath();

  // If optionalDependency not found, try downloading from npm
  if (!binaryPath) {
    console.log('Platform-specific binary not found in optionalDependencies.');
    try {
      binaryPath = await downloadBinaryFromNpm();
    } catch (e) {
      console.log(
        `Failed to download binary: ${e.message}\n` +
          'The "droid" command will use the JavaScript fallback.\n' +
          'For better performance, ensure optionalDependencies are installed.'
      );
      return;
    }
  }

  // On Windows, we can't replace the shim with the binary due to .exe requirement
  // On Yarn 2+, PnP mode has issues with binary modules
  if (process.platform === 'win32' || isYarn2OrAbove()) {
    validateBinaryVersion(binaryPath);
    console.log('Using JavaScript shim for droid command.');
    return;
  }

  // On Unix, replace the JavaScript shim with a hard link to the binary
  // First, backup the shim in case linking fails
  const shimBackupPath = shimPath + '.backup';
  let shimBackedUp = false;

  try {
    // Backup the existing shim
    if (fs.existsSync(shimPath)) {
      fs.copyFileSync(shimPath, shimBackupPath);
      shimBackedUp = true;
    }

    // Remove the existing shim
    fs.unlinkSync(shimPath);

    // Create a hard link to the binary
    fs.linkSync(binaryPath, shimPath);

    // Clean up backup
    if (shimBackedUp) {
      fs.unlinkSync(shimBackupPath);
    }

    validateBinaryVersion(shimPath);
    console.log(
      'Optimized: droid command now runs the native binary directly.'
    );
  } catch (e) {
    // If hard link fails (e.g., cross-device), try symlink
    try {
      fs.symlinkSync(binaryPath, shimPath);

      // Clean up backup
      if (shimBackedUp) {
        fs.unlinkSync(shimBackupPath);
      }

      console.log('Optimized: droid command linked to native binary.');
    } catch (e2) {
      // Restore the shim from backup
      if (shimBackedUp) {
        try {
          fs.renameSync(shimBackupPath, shimPath);
          console.log(
            'Using JavaScript shim for droid command (optimization failed).'
          );
        } catch (e3) {
          console.error(
            'Failed to restore shim. Please reinstall the package.'
          );
        }
      } else {
        console.log(
          'Using JavaScript shim for droid command (optimization failed).'
        );
      }
    }
  }
}

main()
  .then(() => {
    warnIfNotInPath();
  })
  .catch((e) => {
    console.error('postinstall error:', e.message);
    // Don't fail the install - the JS shim will still work
  });
