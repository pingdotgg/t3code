# droid

> The power of [Factory](https://factory.ai) in your terminal

## Installation

```bash
npm install -g droid
```

If the `droid` command is not found after installing, your npm global bin directory may not be in your PATH. Run the following to fix it:

```bash
# For zsh (macOS default)
echo 'export PATH="$(npm prefix -g)/bin:$PATH"' >> ~/.zshrc && source ~/.zshrc

# For bash (Linux)
echo 'export PATH="$(npm prefix -g)/bin:$PATH"' >> ~/.bashrc && source ~/.bashrc

# For bash (macOS)
echo 'export PATH="$(npm prefix -g)/bin:$PATH"' >> ~/.bash_profile && source ~/.bash_profile

# For fish
echo 'fish_add_path "$(npm prefix -g)/bin"' >> ~/.config/fish/config.fish && source ~/.config/fish/config.fish
```

On Windows, run in PowerShell:

```powershell
[Environment]::SetEnvironmentVariable('Path', $env:PATH + ';' + (npm prefix -g), 'User')
```

Then restart your terminal.

Then navigate to your project and start the droid CLI:

```bash
cd /path/to/your/project
droid
```

You're now connected to Factory's development agent from your terminal.

> **Quick tip:** Press `!` to toggle bash mode and run shell commands directly without AI interpretation. Press `Esc` to return to normal mode.

## What droid brings to your workflow

- **End-to-end feature development**: From planning to implementation to testing - droid handles the complete development lifecycle while keeping you in control through transparent review workflows.
- **Deep codebase understanding**: Leverages your organization's shared knowledge across repositories, documentation, and issue tracking to provide contextually aware assistance that improves over time.
- **Engineering system integration**: Connects directly to your existing tools — with native integrations to Jira, Notion, Slack, and many more tools — so development work stays synchronized with your team's processes.
- **Production-ready automation**: Deploy the same workflows locally during development or in CI/CD pipelines, with enterprise security and compliance built-in from day one.

## Why teams choose Factory

- **Built for enterprise**: On-premise deployment options, SOC-2 compliance, and air-gapped environments.
- **Your tools, enhanced**: Works within your existing terminal, IDE, and development environment.
- **Transparent and controllable**: Every decision droid makes is visible and reviewable. You maintain full oversight of code changes with our native diff viewer and approval workflows.
- **Model flexibility**: Not locked into a single AI provider. Factory allows you to route tasks to the best model for each job while maintaining consistent behavior and memory across your organization.

## Documentation

- [Quickstart Guide](https://docs.factory.ai/cli/getting-started/quickstart)
- [Common Use Cases](https://docs.factory.ai/cli/getting-started/common-use-cases)
- [IDE Integration](https://docs.factory.ai/cli/configuration/ide-integrations)
- [Configuration](https://docs.factory.ai/cli/configuration/settings)
- [AGENTS.md Guide](https://docs.factory.ai/cli/configuration/agents-md)
- [CLI Reference](https://docs.factory.ai/reference/cli-reference)

## Full Documentation Index

Fetch the complete documentation index at: https://docs.factory.ai/llms.txt
